<?php
	session_start();
	//connection
	$conn = new mysqli('localhost', 'root', '', 'smart_attendance');
 
	$sql = "SELECT * FROM student";
	$query = $conn->query($sql);
 
	if($query->num_rows > 0){
		$delimiter = ',';
		//create a download filename
		$filename = 'test.csv';
 
		$f = fopen('php://memory', 'w');
 
		$headers = array('student_firstname','student_lastname','student_usn','student_phnumber','student_branch','student_semester','student_section');
    	fputcsv($f, $headers, $delimiter);
 
    	while($row = $query->fetch_array()){
	        $lines = array($row['student_firstname'], $row['student_lastname'], $row['student_usn'],$row['student_phnumber'],$row['student_branch'],$row['student_semester'],$row['student_section']);
	        fputcsv($f, $lines, $delimiter);
	    }
 
	    fseek($f, 0);
	    header('Content-Type: text/csv');
	    header('Content-Disposition: attachment; filename="' . $filename . '";');
	    fpassthru($f);
	    exit;
	}
	else{
		$_SESSION['message'] = 'Cannot export. Data empty';
		header('location:index.php');
	}
?>