<?php
if(isset($_POST['fname'])){
$FirstName=strtoupper($_POST['fname']);}
if(isset($_POST['lname'])){
$LastName=strtoupper($_POST['lname']);}
if(isset($_POST['dob'])){
$Date_Of_Birth=$_POST['dob'];}
if(isset($_POST['sex'])){
$Sex=$_POST['sex'];}
if(isset($_POST['phone_no'])){
$phno=$_POST['phone_no'];}
if(isset($_POST['branch'])){
$branch=$_POST['branch'];}
if(isset($_POST['role'])){
$role=$_POST['role'];}
if(isset($_POST['emailid'])){
$email=$_POST['emailid'];}
if(isset($_POST['role_id'])){
$Role_id=$_POST['role_id'];}

require_once("config.php");


if(isset($_POST['submit']))
 {

 $q1=mysqli_query($conn,"UPDATE login SET firstname='$FirstName',lastname='$LastName',DOB='$Date_Of_Birth',sex='$Sex',phno='$phno',branch='$branch',role_id='$role',email_id='$email',role_id='$Role_id' where phno='$phno'");

	echo "<script> alert('Updated Sucessfully..!!!');
window.location.href='registration_list.php';
</script>";


}

 
?>