  <?php
//session_start();

  if(($_SESSION["role_id"])=="1")
  { 
    ?>
	<ul class="nav nav-list">
				
				
		
					<li class="">
						<a href="notice.php">
							<i class="menu-icon fa  fa-cog"></i>
							<span class="menu-text">
							Notice/Circulars
							</span>

							
						</a>

						
					</li>

					<li class="">
						<a href="s_notes.php" >
							<i class="menu-icon fa fa-user"></i>
							<span class="menu-text"> Notes </span>

							
						</a>

					

						
					</li>
					
					<li class="">
						<a href="events.php" >
							<i class="menu-icon fa fa-book"></i>
							<span class="menu-text"> Events </span>

							
						</a>

					

						
					</li>	
<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon  glyphicon-pencil "></i>
							<span class="menu-text"> My Attendance </span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="predict_attendance.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Prediction
								</a>

								<b class="arrow"></b>
							</li>

						</ul>
						<ul class="submenu">
							<li class="">
								<a href="attendance_report.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Report
								</a>

								<b class="arrow"></b>
							</li>

						</ul>
					</li>		
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon  glyphicon-pencil "></i>
							<span class="menu-text"> Query </span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="query_post.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Post Query
								</a>

								<b class="arrow"></b>
							</li>

						</ul>
						<ul class="submenu">
							<li class="">
								<a href="answer_query.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Answered Queries
								</a>

								<b class="arrow"></b>
							</li>

						</ul>
					</li>	
<li class="">
						<a href="student_profile.php">
							<i class="menu-icon fa fa-book"></i>
							<span class="menu-text"> My Profile </span>

							
						</a>

					

						
					</li>						
					
				</ul>
				
				
	
		<!--<ul class="nav nav-list">
					<li class="">
							<a href="academic.php">
							<i class="menu-icon glyphicon glyphicon-lock"></i>
							<span class="menu-text"> Add Academic Year </span>
						</a>

						<b class="arrow"></b>
					</li>
					</ul>
					<ul class="nav nav-list">
					<li class="" id="add">
						<a href="semester.php">
							<i class="menu-icon fa fa-user"></i>
							<span class="menu-text" > Add Semester </span><br>
							
						</a>

						<b class="arrow"></b>
					</li>
					</ul>
  <ul class="nav nav-list">
					<li class="active">
						<a href="list.php">
							<i class="menu-icon glyphicon glyphicon-education"></i>
							<span class="menu-text"> Student List </span><br>
							
						</a>

						<b class="arrow"></b>
					</li>
				
</ul>

				<ul class="nav nav-list">
					<li class="" id="add">
						<a href="AddStudent.php">
							<i class="menu-icon fa fa-user"></i>
							<span class="menu-text" > Add Student </span><br>
							
						</a>

						<b class="arrow"></b>
					</li>
					</ul>

			
					<ul class="nav nav-list">
					<li class="">
							<a href="faculty_login.php">
							<i class="menu-icon glyphicon glyphicon-lock"></i>
							<span class="menu-text"> Add Faculty </span>
						</a>

						<b class="arrow"></b>
					</li>
					</ul>
					
					
				<!-- /.nav-list -->
				
				
				
 <?php    }  ?>
 <?php
 if(($_SESSION["role_id"])=="2")
  { 
    ?>
	<ul class="nav nav-list">
					<li class="">
						<a href="faculty_notice.php">
							<i class="menu-icon fa fa-bell"></i>
							<span class="menu-text"> Circular/Notice </span><br>
							
						</a>

				
					</li>
			
				
				
		
					<li class="">
						<a href="upload_notes.php">
							<i class="menu-icon fa fa-upload"></i>
							<span class="menu-text"> Upload Notes </span><br>
							
						</a>

					
					</li>
			

<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon  fa fa-calendar "></i>
							<span class="menu-text"> Events </span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="faculty_events.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Post Events
								</a>

								<b class="arrow"></b>
							</li>

						</ul>
						<ul class="submenu">
							<li class="">
								<a href="faculty_eventlist.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Events List
								</a>

								<b class="arrow"></b>
							</li>

						</ul>
					</li>
					
					
			<li class="">
						<a href="subsem_selection.php">
							<i class="menu-icon fa fa-link"></i>
							<span class="menu-text"> Choose Subject </span><br>
							
						</a>

					
					</li>		
					
			<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon  glyphicon-pencil "></i>
							<span class="menu-text"> Attendance </span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="take_attendance.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Take Attendance
								</a>

								<b class="arrow"></b>
							</li>

						</ul>
						<ul class="submenu">
							<li class="">
								<a href="generate_report.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Generate Report
								</a>

								<b class="arrow"></b>
							</li>

						</ul>
						<ul class="submenu">
							<li class="">
								<a href="fac_attendancereport.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Attendance Report
								</a>

								<b class="arrow"></b>
							</li>

						</ul>
					</li>		
					
					
					<li class="">
						<a href="faculty_queryanswer.php">
							<i class="menu-icon fa fa-pencil"></i>
							<span class="menu-text"> Answer queries </span><br>
							
						</a>

					
					</li>	
					
					
						
<li class="">
						<a href="faculty_profile.php">
							<i class="menu-icon fa fa-user"></i>
							<span class="menu-text"> My Profile </span><br>
							
						</a>

					
					</li>	

			</ul>	
				
  <?php } ?>
   <?php
 if(($_SESSION["role_id"])=="3")
  { 
    ?>
	<ul class="nav nav-list">
					<li class="">
						<a href="a_notice.php">
							<i class="menu-icon fa fa-bell"></i>
							<span class="menu-text"> Admin Notice </span><br>
							
						</a>

						<b class="arrow"></b>
					</li>
					
					<li class="">
						<a href="academic_calender.php">
							<i class="menu-icon fa fa-calendar"></i>
							<span class="menu-text"> Academic calender </span><br>
							
						</a>

						<b class="arrow"></b>
					</li>
				
					
					
					<li class="">
						<a href="#" class="dropdown-toggle">
							<i class="menu-icon  glyphicon-pencil "></i>
							<span class="menu-text"> Attendance </span>

							<b class="arrow fa fa-angle-down"></b>
						</a>

						<b class="arrow"></b>

						<ul class="submenu">
							<li class="">
								<a href="st_attendance.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Student attendance
								</a>

								<b class="arrow"></b>
							</li>

						</ul>
						<ul class="submenu">
							<li class="">
								<a href="map.php">
									<i class="menu-icon fa fa-caret-right"></i>
									Faculty attendance
								</a>

								<b class="arrow"></b>
							</li>

						</ul>
						
					</li>		
					
					<li class="">
						<a href="admin_profile.php">
							<i class="menu-icon fa fa-user"></i>
							<span class="menu-text"> Admin Profile </span><br>
							
						</a>

						<b class="arrow"></b>
					</li>
					
					<li class="">
						<a href="admin_approve.php">
							<i class="menu-icon fa fa-check"></i>
							<span class="menu-text"> Admin approve </span><br>
							
						</a>

						<b class="arrow"></b>
					</li>
					
					
					
				</ul>
  <?php } ?>
  
   <?php
 if(($_SESSION["role_id"])=="4")
  { 
    ?>
	<ul class="nav nav-list">
					<li class="">
						<a href="pa_notice.php">
							<i class="menu-icon fa fa-bell"></i>
							<span class="menu-text">  Notices </span><br>
							
						</a>

						<b class="arrow"></b>
					</li>
					
					<li class="">
						<a href="pa_events.php">
							<i class="menu-icon fa fa-calendar"></i>
							<span class="menu-text"> Academic calender </span><br>
							
						</a>

						<b class="arrow"></b>
					</li>
				
					
					
						
					
					<li class="">
						<a href="pa_profile.php">
							<i class="menu-icon fa fa-user"></i>
							<span class="menu-text"> My Profile </span><br>
							
						</a>

						<b class="arrow"></b>
					</li>
					
				
					
					
				</ul>
  <?php } ?>