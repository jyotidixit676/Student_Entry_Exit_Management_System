 
<?php
require_once 'config.php';
	  $resp=array();
	 
	    $semester=$_POST['sem'];
		$section=$_POST['sec'];
	  
	    $query=("select * from student_table where  semister='$semester' and section='$section'");
		//echo $query;
		//die();
		$d=array();
		$r=mysqli_query($conn,$query);
		$ro=mysqli_num_rows($r);
		$i=0;
		
		while($ro=mysqli_fetch_array($r)){
			
			$d[]=$ro['usn'];
			$i++;
		}
		//$res=mysqli_fetch_array($r);
	  $resp["usn"]=$d;
	   echo json_encode($resp);
?>	  
 
    