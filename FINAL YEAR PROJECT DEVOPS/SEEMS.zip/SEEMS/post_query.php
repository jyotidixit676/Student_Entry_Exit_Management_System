<?php
session_start();

$branch=$_POST['branch'];
$sem=$_POST['sem'];
$subject=$_POST['subject'];
$query=$_POST['query'];
$posted_by=$_SESSION['user_id'];
require_once("config.php");
$faculty_check="select * from faculty_semisterlink where branch='$branch' and subject_code='$subject'";
$result_check=mysqli_query($conn,$faculty_check);
while($row_check=mysqli_fetch_array($result_check))
{
	
	$facuser_id=$row_check['user_id'];
} 


//echo $user; echo "<br>";
//echo $pwd;

$sql="insert into student_query(posted_by,query,posted_to,posted_on,branch,subject_code) values('$posted_by','$query','$facuser_id',NOW(),'$branch','$subject')";

$result=mysqli_query($conn,$sql);

if($result){
	echo "Query posted sucessfully";
}
else{
	
	echo "Error in Post";
}



?>
