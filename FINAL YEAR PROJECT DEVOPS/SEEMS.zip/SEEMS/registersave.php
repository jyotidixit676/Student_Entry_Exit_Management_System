<?php
session_start();
extract($_POST);
$uname=$_POST['uname'];
$role_id=$_POST["role"];
//$pass=$_POST['pwd'];

if($role_id==1)
	
	{
		$usn=$_POST["usn"];
		$sem=$_POST["sem"];
	$sec=$_POST["sec"];
	}

$DOB=$_POST['dob'];
$Sex=strtoupper($_POST['sex']);
$ph_no=$_POST['phone_no'];
$branch=strtoupper($_POST['branch']);
$Role='0';
$Email_id=$_POST['emailid'];


function password_generate($chars) 
{
  $data = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
  return substr(str_shuffle($data), 0, $chars);
}
 // echo password_generate(7)."\n";
  $ppp=password_generate(7);
 // echo $ppp;
    $subject ="Successfully Registered to SEEMS";
	$from="seems.cse4@gmail.com";
	//$message =$name." ".$mobile." ".$query;
	$message="Congratulations!!! \n".
	"A Very Special Welcome to $uname, Thank you for joining Sapthagiri SEEMS. \n".
   "Your registration process is successfull. Please use the below details to login to the system. \n".
        "Username: $uname \n".
		 "Username: $Email_id \n".
        "Password: $ppp \n".
		"Please login to the system for further use.";
//echo $uname;
   $headers = "From:".$from;
    mail($Email_id,$subject,$message,$headers);
 //$modify= $_SESSION['User_Name'];


//$confirmpass=$_POST['pwdd'];

//$modify='User_Name';

require_once("config.php");
//$cur=date("Y");
//echo $cur;
//$dep=$_POST['Branch'];
//echo $dep;
//$conn=new mysqli('localhost','root','','registration');





	$q3 = "SELECT user_name,password from user_mst WHERE user_name='$uname' and password='$ppp'";
	
	
	$q4 = mysqli_query($conn,$q3);
	if(mysqli_num_rows($q4) > 1){
		//header("Location:register.php");
	
	echo "<script> alert('User Already exists.!');
window.location.href='register.php';



	</script>";}
	


else{

$sql="insert into user_mst(user_name,password,role_id,email,mobile_num,	status,dob,gender,branch) values ('$uname','$ppp','$role_id','$Email_id','$ph_no','inactive','$DOB','$Sex','$branch')";
//echo "dfks"+$sql;
//die();
$result=mysqli_query($conn,$sql);

$last_id = $conn->insert_id;


if($role_id==1)
{
	
$sql1="insert into student_table(user_id,semister,usn,section) values('$last_id','$sem','$usn','$sec')";
$result1=mysqli_query($conn,$sql1);	
	
}

	//header("Location:AddStudent.php");
	echo "<script> alert('Registered Sucessfully.!');
window.location.href='Index.php';



	</script>";
	//echo '<script language="javascript">';
    //echo 'alert("Successfully Registered")';
	//$_SESSION['msg2']="data inserted Sucessfully and your Temporary USN is <a href=form1.php? >".$n."</a>";
	
//echo '</script>';


//echo $sql;
}
 mysqli_close($conn);



?>