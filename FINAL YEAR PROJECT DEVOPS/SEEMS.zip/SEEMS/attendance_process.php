<?php
session_start();


    require_once 'config.php';
   
	  $faculty=$_REQUEST["faculty"];
	  $semester=$_REQUEST["semester"];
	  $section=$_REQUEST["section"];
	  $subcode=$_REQUEST["subcode"];
	  $timings=$_REQUEST["timings"];
	  $USN=$_REQUEST["USN"];
	  $branch=$_SESSION['branch'];
	  //echo $USN;
      $b=implode(",",$USN);
	  $count=$_REQUEST["count"];
	  //echo $count;
	  //die();
	//  $c=implode($count);
	
  
	$newTrans=  mysqli_query($conn,"insert into attendance_tracker(faculty,semester,section,subcode,timings,USN,count,class_taken,branch)values('$faculty','$semester','$section','$subcode','$timings','$b','$count',now(),'$branch')");

//echo $newTrans;
//die();
		if($newTrans)
	{  
	
    echo "<script> alert('Attendance taken Successfully');
       window.location.href='take_attendance.php';




</script>";}
	else {
echo "<script> alert('plz take attendance once again ');
window.location.href='take_attendance.php';




</script>";
}	


?>
