-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 21, 2019 at 07:48 AM
-- Server version: 10.0.17-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `elms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `UserName` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `UserName`, `Password`, `updationDate`) VALUES
(1, 'admin', 'admin', '2019-02-21 06:38:00');

-- --------------------------------------------------------

--
-- Table structure for table `data_entry`
--

CREATE TABLE `data_entry` (
  `d_id` int(11) NOT NULL,
  `project` varchar(50) NOT NULL,
  `curdate` varchar(50) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `description` varchar(500) NOT NULL,
  `empid` int(10) NOT NULL,
  `created_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_entry`
--

INSERT INTO `data_entry` (`d_id`, `project`, `curdate`, `start_time`, `end_time`, `description`, `empid`, `created_date`) VALUES
(1, 'Project1', '', '12:02:00', '00:01:00', 'fdgdfg', 0, '0000-00-00 00:00:00'),
(2, 'Project1', '', '12:33:00', '14:03:00', 'fxdfsg', 0, '0000-00-00 00:00:00'),
(3, 'Project1', '', '12:01:00', '17:04:00', 'sdfsdf', 0, '0000-00-00 00:00:00'),
(4, 'Project1', '', '12:32:30', '16:02:30', 'sadfasfasd', 0, '0000-00-00 00:00:00'),
(5, 'aa', '', '12:32:00', '12:32:00', 'sadfasfasd', 0, '0000-00-00 00:00:00'),
(6, 'Project1', '', '02:13:00', '12:31:00', 'DFSDF', 0, '0000-00-00 00:00:00'),
(7, '', '', '12:31:00', '12:31:00', 'dsafsdfsdf', 0, '0000-00-00 00:00:00'),
(8, 'sdfsdf', '', '14:13:00', '12:33:00', 'sdfsdfs', 0, '0000-00-00 00:00:00'),
(9, 'sadad', '', '14:32:00', '14:32:00', 'sdfsfs', 0, '0000-00-00 00:00:00'),
(10, 'chch', '', '12:01:00', '02:44:00', 'vbhvbhjbj', 0, '0000-00-00 00:00:00'),
(11, 'asdad', '', '14:13:00', '02:31:00', 'sadfsdf', 0, '0000-00-00 00:00:00'),
(12, 'asdas', '', '12:31:00', '01:12:00', 'fsdfdsf', 0, '0000-00-00 00:00:00'),
(13, 'asdasd', '', '02:13:00', '14:13:00', 'sadasds sdad sdadsad', 0, '0000-00-00 00:00:00'),
(14, 'asdadadas', '', '12:31:00', '12:31:00', 'asdasda', 0, '0000-00-00 00:00:00'),
(15, 'CMP', '', '19:15:00', '21:15:00', 'Uploading data ', 1, '0000-00-00 00:00:00'),
(16, 'dsfsdfsdfsdf', '', '12:31:00', '12:31:00', 'SAFDASFDAF', 1, '0000-00-00 00:00:00'),
(17, 'asdasda', '', '12:31:00', '02:13:00', 'sdasdas', 1, '2019-01-22 13:28:18'),
(18, 'sdad', '2019-01-17', '12:31:00', '12:32:00', 'asdasdasdasd', 1, '2019-01-22 13:29:31'),
(19, 'edsasfd', '2019-01-09', '06:00:00', '20:00:00', 'sdadsadas asda sasdasdas', 1, '2019-01-22 13:41:33'),
(20, 'CMP', '2019-01-23', '19:45:00', '20:45:00', 'Uploading voter details of meerapur to a database', 5, '2019-01-23 13:33:21'),
(21, 'CMP', '2019-01-18', '12:03:00', '18:59:00', 'asdsafsdafdsf sdfsadfasd', 5, '2019-01-23 14:12:05'),
(22, 'sadsadfasdassadsa', '2019-01-24', '12:12:00', '17:03:00', 'sadasds sdad sdadsaddsadad', 5, '2019-01-23 14:13:22'),
(23, 'sadasda', '2019-01-18', '12:01:00', '17:34:00', 'sad asdasd', 5, '2019-01-23 14:17:36'),
(24, 'asdasd', '2019-01-08', '02:13:00', '15:24:00', 'sdfsdfsdf', 5, '2019-01-23 14:18:36'),
(25, 'asdasdasd', '2019-01-18', '02:13:00', '14:34:00', 'dfdsgfsdfdfds', 5, '2019-01-23 14:21:02'),
(26, 'sadasda', '2019-01-03', '12:12:00', '00:21:00', 'sdfsdf', 5, '2019-01-23 14:21:49'),
(27, 'sdgfsdafsad', '2019-01-04', '12:43:00', '16:05:00', 'dsffds sdfsad', 5, '2019-01-23 14:22:31'),
(28, 'a', '2019-01-11', '02:13:00', '15:24:00', 'fgdfgdfg', 8, '2019-01-23 14:32:09'),
(29, 'dfgdgdf', '2019-01-02', '11:00:00', '19:40:00', 'testing', 1, '2019-01-28 11:07:58'),
(30, 'CMP432535', '2019-01-25', '12:03:00', '16:35:00', 'fdg dfg dsf', 10, '2019-01-28 13:35:03'),
(31, 'sdfsdfsdf', '2019-01-25', '12:00:00', '14:00:00', 'sdfgfdsgsdfg', 10, '2019-01-28 14:22:42'),
(32, 'ECOGRAMAMAMA', '2019-01-23', '12:03:00', '16:56:00', 'fdgdsfgdfgdfsg', 10, '2019-01-28 15:59:25'),
(33, 'proj1', '2019-01-30', '05:45:00', '09:43:00', 'proj1 work in progress', 5, '2019-01-30 11:40:56'),
(34, 'CMP', '2019-02-07', '14:13:00', '18:01:00', 'xsfsdf', 7, '2019-02-12 11:10:37'),
(35, 'CMP23', '2019-02-19', '00:58:00', '19:55:00', 'yuiyiuyi', 1, '2019-02-19 11:16:15'),
(36, 'CMP', '2019-02-19', '03:40:00', '12:30:00', 'dfgdfgdfg', 1, '2019-02-19 16:21:46'),
(37, 'dsfsdfsdf', '2019-02-20', '04:00:00', '12:50:00', 'fghgfh', 1, '2019-02-20 16:12:54'),
(38, 'fdgs', '2019-02-13', '06:00:00', '20:57:00', 'dfgdfgs', 1, '2019-02-20 17:45:25'),
(39, 'defew', '2019-02-20', '01:02:00', '01:01:00', 'hjkhk', 1, '2019-02-20 17:52:31'),
(40, 'fgh', '2019-02-20', '15:42:00', '14:02:00', 'hgjkgh', 1, '2019-02-20 17:54:49'),
(41, 'ecogram', '2019-02-21', '05:04:00', '13:16:00', 'working on ecogram', 7, '2019-02-21 12:15:47');

-- --------------------------------------------------------

--
-- Table structure for table `tbldepartments`
--

CREATE TABLE `tbldepartments` (
  `id` int(11) NOT NULL,
  `DepartmentName` varchar(150) DEFAULT NULL,
  `DepartmentShortName` varchar(100) NOT NULL,
  `DepartmentCode` varchar(50) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbldepartments`
--

INSERT INTO `tbldepartments` (`id`, `DepartmentName`, `DepartmentShortName`, `DepartmentCode`, `CreationDate`) VALUES
(1, 'Human Resource', 'HR', 'HR001', '2017-11-01 07:16:25'),
(2, 'Information Technology', 'IT', 'IT001', '2017-11-01 07:19:37'),
(3, 'Operations', 'OP', 'OP1', '2017-12-02 21:28:56');

-- --------------------------------------------------------

--
-- Table structure for table `tblemployees`
--

CREATE TABLE `tblemployees` (
  `id` int(11) NOT NULL,
  `EmpId` varchar(100) NOT NULL,
  `FirstName` varchar(150) NOT NULL,
  `LastName` varchar(150) NOT NULL,
  `EmailId` varchar(200) NOT NULL,
  `Password` varchar(180) NOT NULL,
  `Gender` varchar(100) NOT NULL,
  `Dob` varchar(100) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `City` varchar(200) NOT NULL,
  `Country` varchar(150) NOT NULL,
  `Phonenumber` char(11) NOT NULL,
  `Status` int(1) NOT NULL,
  `RegDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblemployees`
--

INSERT INTO `tblemployees` (`id`, `EmpId`, `FirstName`, `LastName`, `EmailId`, `Password`, `Gender`, `Dob`, `Department`, `Address`, `City`, `Country`, `Phonenumber`, `Status`, `RegDate`) VALUES
(1, 'EMP10806121', 'Johnny', 'doe', 'pramod01111@gmail.com', 'b59c67bf196a4758191e42f76670ceba', 'Male', '3 February, 1990', 'Human Resource', 'N NEPO', 'NEPO', 'IRE', '9857555555', 1, '2017-11-10 11:29:59'),
(2, 'DEMP2132', 'James', 'doe', 'james@gmail.com', 'f925916e2754e5e03f75dd58a5733251', 'Male', '3 February, 1990', 'Information Technology', 'N NEPO', 'NEPO', 'IRE', '8587944255', 1, '2017-11-10 13:40:02');

-- --------------------------------------------------------

--
-- Table structure for table `tblleaves`
--

CREATE TABLE `tblleaves` (
  `id` int(11) NOT NULL,
  `LeaveType` varchar(110) NOT NULL,
  `ToDate` varchar(120) NOT NULL,
  `FromDate` varchar(120) NOT NULL,
  `Description` mediumtext NOT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `AdminRemark` mediumtext,
  `AdminRemarkDate` varchar(120) DEFAULT NULL,
  `Status` int(1) NOT NULL,
  `IsRead` int(1) NOT NULL,
  `empid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblleaves`
--

INSERT INTO `tblleaves` (`id`, `LeaveType`, `ToDate`, `FromDate`, `Description`, `PostingDate`, `AdminRemark`, `AdminRemarkDate`, `Status`, `IsRead`, `empid`) VALUES
(7, 'Casual Leave', '30/11/2017', '29/10/2017', 'test description test descriptiontest descriptiontest descriptiontest descriptiontest descriptiontest descriptiontest description', '2017-11-19 13:11:21', 'Lorem Ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.\r\n', '2017-12-02 23:26:27 ', 2, 1, 1),
(8, 'Medical Leave test', '21/10/2017', '25/10/2017', 'test description test descriptiontest descriptiontest descriptiontest descriptiontest descriptiontest descriptiontest description', '2017-11-20 11:14:14', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', '2017-12-02 23:24:39 ', 1, 1, 1),
(9, 'Medical Leave test', '08/12/2017', '12/12/2017', 'Lorem Ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.\r\n', '2017-12-02 18:26:01', NULL, NULL, 0, 1, 2),
(10, 'Restricted Holiday(RH)', '25/12/2017', '25/12/2017', 'Lorem Ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.', '2017-12-03 08:29:07', 'Lorem Ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.', '2017-12-03 14:06:12 ', 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblleavetype`
--

CREATE TABLE `tblleavetype` (
  `id` int(11) NOT NULL,
  `LeaveType` varchar(200) DEFAULT NULL,
  `Description` mediumtext,
  `CreationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblleavetype`
--

INSERT INTO `tblleavetype` (`id`, `LeaveType`, `Description`, `CreationDate`) VALUES
(1, 'Casual Leave', 'Casual Leave ', '2017-11-01 12:07:56'),
(2, 'Medical Leave test', 'Medical Leave  test', '2017-11-06 13:16:09'),
(3, 'Restricted Holiday(RH)', 'Restricted Holiday(RH)', '2017-11-06 13:16:38');

-- --------------------------------------------------------

--
-- Table structure for table `tblregister`
--

CREATE TABLE `tblregister` (
  `user_id` int(10) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mobileno` bigint(10) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `passwd` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblregister`
--

INSERT INTO `tblregister` (`user_id`, `fname`, `lname`, `gender`, `email`, `mobileno`, `dob`, `passwd`, `created_at`) VALUES
(1, 'dssd', 'fddsfsd', 'Female', 'dsf@navigem.com', 3242342342, '0000-00-00', '1111', '2019-01-23 11:56:47'),
(2, 'sdfsa', 'sdfsad', 'Female', 'sd@na.com', 1231242134, '0000-00-00', '2222', '2019-01-23 11:57:04'),
(3, 'sdfsa', 'sdfsad', 'Female', 'sd@na.com', 1231242134, '25 January, 2019', '2222', '2019-01-23 11:58:15'),
(4, 'ASs SASA', 'ASDASAS', 'Female', 'dfsf@na.com', 2131231231, '10 January, 2019', '2222', '2019-01-23 11:58:40'),
(5, 'shiva', 'kumar', 'Male', 'skumar@navigem.com', 9004047728, '22 January, 2019', 'shivu', '2019-01-23 13:31:15'),
(6, 'Pramod', 'R', 'Male', 'rpramod@navigem.com', 9036296140, '10 January, 2019', '1111', '2019-01-23 14:28:58'),
(7, 'Pramod', 'R', 'Male', 'rpramod@navigem.com', 9036296140, '10 January, 2019', '1111', '2019-01-23 14:29:52'),
(8, 'asdfasd', 'fasdfas', 'Female', 'sdasd@n.com', 1234123421, '18 January, 2019', '2222', '2019-01-23 14:30:41'),
(9, 'kumar', 's', 'Male', 'kumar@navigem.com', 7788778877, '18 January, 2019', 'kumar', '2019-01-23 18:26:47'),
(10, 'Pramod', 'R', 'Male', 'r@navigem.com', 6696666666, '16 January, 2019', '1111', '2019-01-28 13:34:34'),
(11, 'test12', 'test12', 'Male', 'test@navigem.com', 9558445578, '30 January, 2019', 'test12', '2019-01-30 12:02:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_entry`
--
ALTER TABLE `data_entry`
  ADD PRIMARY KEY (`d_id`);

--
-- Indexes for table `tbldepartments`
--
ALTER TABLE `tbldepartments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblemployees`
--
ALTER TABLE `tblemployees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblleaves`
--
ALTER TABLE `tblleaves`
  ADD PRIMARY KEY (`id`),
  ADD KEY `UserEmail` (`empid`);

--
-- Indexes for table `tblleavetype`
--
ALTER TABLE `tblleavetype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblregister`
--
ALTER TABLE `tblregister`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `data_entry`
--
ALTER TABLE `data_entry`
  MODIFY `d_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `tbldepartments`
--
ALTER TABLE `tbldepartments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tblemployees`
--
ALTER TABLE `tblemployees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `tblleaves`
--
ALTER TABLE `tblleaves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `tblleavetype`
--
ALTER TABLE `tblleavetype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tblregister`
--
ALTER TABLE `tblregister`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
