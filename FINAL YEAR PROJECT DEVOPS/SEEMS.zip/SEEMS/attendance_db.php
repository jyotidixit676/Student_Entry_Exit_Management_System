<?php
session_start();

$semester=$_POST['semester'];
$section=$_POST['section'];
$subject=$_POST['subject'];
$timings=$_POST['timings'];
$modify=$_SESSION['UserName'];

require_once("config.php");
$sql = "INSERT INTO attendance(a_semester,a_section,a_subject,a_timings,created_date,updated_by) VALUES ('$semester','$section','$subject','$timings',now(),'$modify')";
$result=mysqli_query($conn,$sql);
if($result)
{

	echo "<script> alert('Submitted Successfully');
window.location.href='attendance.php';




</script>";}
	else {
echo "<script> alert('Unsuccessfully ');
window.location.href='attendance.php';




</script>";}		
	

?>
