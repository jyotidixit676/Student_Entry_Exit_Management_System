<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/d3js/5.7.0/d3.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-show-password/1.0.3/bootstrap-show-password.min.js"></script>
<script>
$(document).ready(function() {
    setInterval(timestamp, 1000);
});

function timestamp() {
    $.ajax({
        url: 'timestamp.php',
        success: function(data) {
			//alert(data);
            $('#timestamp').html(data);
        },
    });
}
</script>
</head>
<body>
<footer class="page-footer font-small blue" style="position: fixed; bottom: 0; width:100%;"">
<div class="footer-copyright text-right py-3" >
<div id="timestamp"></div>
</div>
</footer>
</body>

</html>