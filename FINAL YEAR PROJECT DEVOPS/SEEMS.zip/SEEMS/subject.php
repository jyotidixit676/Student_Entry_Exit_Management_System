<?php
session_start();
if(isset($_SESSION["UserName"]))
{
 if((time() - $_SESSION['last_time']) > 500) // Time in Seconds
 {
 header("location:Index.php");
 }
else
 {
 $_SESSION['last_time'] = time();
 }
}


?>
<!DOCTYPE html>

<html lang="en">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
	<head>
	<link rel="icon" href="images/SIT.ico" type="image/x-icon" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta charset="utf-8" />
		<title>Subject</title>

		<meta name="description" content="Common form elements and layouts" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

		<!-- bootstrap & fontawesome -->
		<link rel="stylesheet" href="assets/css/bootstrap.min.css" />
		<link rel="stylesheet" href="assets/font-awesome/4.5.0/css/font-awesome.min.css" />

		<!-- page specific plugin styles -->
		<link rel="stylesheet" href="assets/css/jquery-ui.custom.min.css" />
		<link rel="stylesheet" href="assets/css/chosen.min.css" />
		<link rel="stylesheet" href="assets/css/bootstrap-datepicker3.min.css" />
		<link rel="stylesheet" href="assets/css/bootstrap-timepicker.min.css" />
		<link rel="stylesheet" href="assets/css/daterangepicker.min.css" />
		<link rel="stylesheet" href="assets/css/bootstrap-datetimepicker.min.css" />
		<link rel="stylesheet" href="assets/css/bootstrap-colorpicker.min.css" />

		<!-- text fonts -->
		<link rel="stylesheet" href="assets/css/fonts.googleapis.com.css" />

		<!-- ace styles -->
		<link rel="stylesheet" href="assets/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />

		<!--[if lte IE 9]>
			<link rel="stylesheet" href="assets/css/ace-part2.min.css" class="ace-main-stylesheet" />
		<![endif]-->
		<link rel="stylesheet" href="assets/css/ace-skins.min.css" />
		<link rel="stylesheet" href="assets/css/ace-rtl.min.css" />
		                

		<!--[if lte IE 9]>
		  <link rel="stylesheet" href="assets/css/ace-ie.min.css" />
		<![endif]-->

		<!-- inline styles related to this page -->

		<!-- ace settings handler -->
		<script src="assets/js/ace-extra.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script> 
		<!-- HTML5shiv and Respond.js for IE8 to support HTML5 elements and media queries -->

		<!--[if lte IE 8]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
	<![endif]-->
	
	<style>
		body{overflow-x:hidden; overflow-y:auto;}
		</style>
		
	
	</head>
	

	<body class="no-skin">
	
	<?php require_once("faculty_Header.php");?>
		
		<div class="main-container ace-save-state" id="main-container">
			<script type="text/javascript">
				try{ace.settings.loadState('main-container')}catch(e){}
			</script>

			<div id="sidebar" class="sidebar responsive ace-save-state">
				<script type="text/javascript">
					try{ace.settings.loadState('sidebar')}catch(e){}
				</script>

				<div id="sidebar" class="sidebar                  responsive                    ace-save-state">
				<script type="text/javascript">
					try{ace.settings.loadState('sidebar')}catch(e){}
				</script>



				<ul class="nav nav-list">
				<li class="">
						<a href="Attendance.php">
							<i class="menu-icon fa fa-book"> </i>
					Take attendance
						</a>

						<b class="arrow"></b>
					</li>
					<li class="active">
						<a href="subject.php">
							<i class="menu-icon fa fa-inbox "></i> 
					Generate report
						</a>

						<b class="arrow"></b>
					</li>
					
					
		
					
					<ul class="nav nav-list">
					<li class="">
						<a href="student_report.php">
							<i class="menu-icon fa  fa-check-square-o "></i> 
					Student report
						</a>

						<b class="arrow"></b>
					</li>

				
					
				
				
					
				</ul><!-- /.nav-list -->
</ul>
			
			</div>

			</div>
			
			 <?php
               require_once 'config.php';
                $query=mysqli_query($conn,"select * from attendance_tracker");
                $rowcount=mysqli_num_rows($query);
   
             ?>

			<div class="main-content">
		

						<div class="page-header">
							<h1><b>
								<b>Attendance Report</b>
							</b>
							</h1>
							
						</div><!-- /.page-header -->					

						<div class="row">
							<div class="col-xs-11">
								<!-- PAGE CONTENT BEGINS -->
								<form class="form-horizontal" role="form">
								
								<!-- PAGE CONTENT BEGINS -->
								<div class="row">
									<div class="col-xs-14">
									<div class="widget-box widget-color-blue">
                            <div class="widget-header">
												<h4 class="widget-title">Attendance</h4>
											</div>
									
							<table id="simple-table" class="table  table-bordered table-hover" >
											<thead>
												<tr>
													<!--<th class="center">
														<label class="pos-rel">
															<input type="checkbox" class="ace" />
															<span class="lbl"></span>
														</label>
													</th>-->
													<!--<th class="detail-col"></th>-->
													<th class="center">ID</th>
													<th class="center">FACULTY</th>
													<th class="center">SEMESTER</th>
													<th class="center">SECTION</th>
													<th class="center">SUBCODE</th>
													<th class="center">TIMINGS</th>
													<th class="center">COUNT</th>
												</tr>
											</thead>
                                      <?php
 
                                      for($i=1;$i<=$rowcount;$i++)
                                         {
	                                      $row=mysqli_fetch_array($query);
	 
	                                   ?>
											
												<tr>
													<td class="center"><?php echo $row['aid'] ?></td>

													<td class="center"><?php echo $row["faculty"]?></td>
													
													<td class="center"><?php echo $row["semester"] ?></td>
													
													<td class="center"><?php echo $row["section"] ?></td>
													
													<td class="center">	<?php echo $row["subcode"] ?></td>
													
													<td class="center"><?php echo $row["timings"] ?></td>
													
													
													<td class="center"><?php echo '<a href=absenties.php?aid='.$row['aid'].'>'.$row['count'].'</a>'  ; ?></td>																																																																																																																																																																									
												</tr> 
												
                                             <?php
                                               }
                                             ?>																																																																	
											
										</table>
									</div><!-- /.span -->
								</div><!-- /.row -->
																														 						   																																															
								</form>  			
							</div><!-- /.col -->
					</div>	<!-- /.row -->
					

			<a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">
				<i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>
			</a>
		</div><!-- /.main-container -->
	
		<!-- basic scripts -->

		<!--[if !IE]> -->

		<!-- <![endif]-->

		<!--[if IE]>
<script src="assets/js/jquery-1.11.3.min.js"></script>
<![endif]-->
<div style="position: relative; text-align: right">
       <?php require_once("footer.php");?> </div>
<script 
    src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"> 
    </script>
	
<script>
				function goback()
				{
					
					window.history.back(-1);
				}
				
				</script>
				<script>
	
				$("#subcode").change(function(){
var usn=document.getElementById("usn").value;
var subcode=document.getElementById("subcode").value;

alert(usn);

$.post("get_attendance_details.php",{usn:usn,subcode:subcode},function(data,status){
alert(data);

})
})
		</script>
		
		
		
	</body>
</html>
