<?php
session_start();

$uid=$_POST['uid'];



require_once("config.php");
$faculty_check="update user_mst  set status='active' where user_id='$uid'";

$result_check=mysqli_query($conn,$faculty_check);


if($result_check){
	echo "User Approved Sucessfully";
}
else{
	
	echo "Error in Approve";
}



?>
