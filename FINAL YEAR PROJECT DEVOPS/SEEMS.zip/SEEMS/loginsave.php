<?php
session_start();

$email=$_POST['email'];
$pwd=$_POST['upwd'];



require_once("config.php");
$sql="select * from user_mst  where email='$email' AND password='$pwd' and status='active'";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_array($result);

$row_num=mysqli_num_rows($result);
echo $row_num;
die;


if($row_num>=1&&$row['role_id']==1)
{
	$_SESSION["user_name"]=$row['user_name'];
	$_SESSION["role_id"]=$row['role_id'];
	
	$_SESSION["user_id"]=$row['user_id'];
		$_SESSION["branch"]=$row['branch'];
	
$id1=$row['user_id'];


$sqlstu="select semister,usn from student_table where user_id='$id1'";

$result1=mysqli_query($conn,$sqlstu);
$row2=mysqli_fetch_array($result1);

	$_SESSION["semister"]=$row2['semister'];
$_SESSION["section"]=$row2['section'];
	
	$_SESSION["usn"]=$row2['usn'];
	
	
	
	header("Location:notice.php");
} else if($row_num>=1&&$row['role_id']==2)
{	
$_SESSION["user_name"]=$row['user_name'];
	$_SESSION["role_id"]=$row['role_id'];
		$_SESSION["user_id"]=$row['user_id'];
			$_SESSION["branch"]=$row['branch'];
		
header("Location:faculty_notice.php");
}
 else if($row_num>=1&&$row['role_id']==3)
{	
$_SESSION["user_name"]=$row['user_name'];
	$_SESSION["role_id"]=$row['role_id'];
		$_SESSION["user_id"]=$row['user_id'];
			$_SESSION["branch"]=$row['branch'];
		
header("Location:a_notice.php");
}
 else if($row_num>=1&&$row['role_id']==4)
{	
$_SESSION["user_name"]=$row['user_name'];
	$_SESSION["role_id"]=$row['role_id'];
		$_SESSION["user_id"]=$row['user_id'];
			$_SESSION["branch"]=$row['branch'];
		
header("Location:pa_notice.php");
}



else{
	
	$_SESSION['vReviewMessage']="User does not Exist";
header("Location:Index.php");
//alert "Please enter valid UserName and Password";
}


?>
