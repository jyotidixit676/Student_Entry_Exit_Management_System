-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2019 at 11:37 PM
-- Server version: 10.0.17-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sems`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `admin_id` int(11) NOT NULL,
  `admin_branch` varchar(100) NOT NULL,
  `admin_semester` varchar(100) NOT NULL,
  `admin_section` varchar(100) NOT NULL,
  `add_subject` varchar(100) NOT NULL,
  `subject_code` varchar(100) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`admin_id`, `admin_branch`, `admin_semester`, `admin_section`, `add_subject`, `subject_code`, `created_date`, `updated_by`) VALUES
(1, 'EC', 'Fourth', 'a', 'sdg', 'asdsaf', '0000-00-00 00:00:00', ''),
(2, 'BT', 'First', 'B', 'sdg', 'sdfd', '0000-00-00 00:00:00', ''),
(3, 'BA', 'Second', 'B', 'sdg', 'sdf', '2019-04-11 17:31:39', ''),
(4, 'CS', 'Sixth', 'C', 'dddd', 'f', '2019-04-12 11:44:33', 'admin'),
(5, 'CS', 'First', 'B', 'ffgf', 'sfdss', '2019-04-16 15:22:30', 'zzz'),
(6, 'BT', 'First', 'A', 'abcdd', 'sfdss', '2019-04-16 15:23:49', 'r'),
(7, 'CHE', 'Second', 'B', 'SF', 'SSF', '2019-04-16 15:28:43', 'r'),
(8, 'CHE', 'IV', 'B', 'sdg', 'ss', '2019-04-17 12:50:53', 'sss'),
(9, 'EC', 'V', 'B', 'science', 'ss', '2019-04-17 12:51:08', 'sss'),
(10, 'CE', 'III', 'A', 'GGG', 'GGG', '2019-04-22 14:39:41', 'admin'),
(11, 'CE', 'II', 'A', 'SCIENCE', 'SCI', '2019-04-22 16:25:29', 'admin'),
(12, 'MCA', 'II', 'A', 'DATA', 'DS', '2019-04-23 11:52:04', 'admin'),
(13, 'CS', 'I', 'A', 'CPROGRAM', 'MCA', '2019-04-23 13:10:37', 'admin'),
(14, 'BA', 'II', 'A', 'CPP', 'MNHH', '2019-04-23 16:15:51', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `attendance_tracker`
--

CREATE TABLE `attendance_tracker` (
  `aid` int(11) NOT NULL,
  `faculty` varchar(200) NOT NULL,
  `semester` varchar(200) NOT NULL,
  `section` varchar(200) NOT NULL,
  `subcode` varchar(200) NOT NULL,
  `timings` varchar(200) NOT NULL,
  `USN` varchar(200) NOT NULL,
  `count` int(200) NOT NULL,
  `class_taken` date NOT NULL,
  `branch` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance_tracker`
--

INSERT INTO `attendance_tracker` (`aid`, `faculty`, `semester`, `section`, `subcode`, `timings`, `USN`, `count`, `class_taken`, `branch`) VALUES
(1, 'hard', 'I', 'A', 'sdfd', '10.30-11.30', 'NJKNKJNIK,', 1, '2019-04-29', 'CSE'),
(2, 'harq', 'I', 'A', 'sdfd', '0', 'NJKNKJNIK,', 2, '2019-05-03', 'CSE'),
(3, 'harer', 'I', 'A', 'asdsaf', '8.30-9.30', '1SI17MCA01,1SI17MCA02,', 2, '2019-05-03', 'CSE'),
(4, 'haras', 'I', 'A', 'asdsaf', '9.30-10.30', 'NJKNKJNIK,1SI17MCA01,1SI17MCA02,1SI17MCA03,1SI17MCA04,', 5, '2019-05-03', 'CSE'),
(5, 'FACULTY', 'I', 'A', 'sco1', '8.30-9.30', '4ps1-ec053,', 1, '2019-05-07', 'CSE'),
(6, 'QQQ', 'I', 'B', 'sco1', '8.30-9.30', '1mj11mca36,', 1, '2019-05-08', 'ISE'),
(7, 'QQQ', 'I', 'B', 'sco1', '11.30-12.30', '1mj11mca36,', 1, '2019-05-08', 'ISE');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(300) NOT NULL,
  `branch_code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branch_id`, `branch_name`, `branch_code`) VALUES
(1, 'COMPUTER_SCIENCE_AND_ENGINEERING', 'CSE'),
(2, 'INFORMATION_SCIENCE_AND_ENGINEERING', 'ISE'),
(3, 'ELECTRICAL_AND_ELECTRONICS_ENGINEERING', 'EEE'),
(4, 'ELECTRONICS_AND_COMMUNICATION_ENGINEERING', 'ECE'),
(5, 'CIVIL_ENGINEERING', 'CIVIL'),
(6, 'MECHANICAL_ENGINEERING', 'ME'),
(7, 'BIOTECHNOLOGY', 'BT'),
(8, 'PLACEMENTS', 'PLACEMENTS'),
(9, 'MANAGEMENT', 'MGMT');

-- --------------------------------------------------------

--
-- Table structure for table `college_events_table`
--

CREATE TABLE `college_events_table` (
  `event_id` int(20) NOT NULL,
  `event_name` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `event_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=Active, 0=Block',
  `posted_by` int(10) NOT NULL,
  `branch_code` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `date`, `created`, `modified`, `status`, `posted_by`, `branch_code`) VALUES
(1, 'ggfgf', '2019-05-14', '2019-05-08 13:10:20', '2019-05-08 13:10:20', 1, 10, 'CSE'),
(3, 'event created', '2019-05-09', '2019-05-08 10:06:52', '2019-05-08 10:06:52', 1, 8, 'CSE'),
(4, 'event for students', '2019-05-14', '2019-05-08 14:16:52', '2019-05-08 14:16:52', 1, 10, 'CSE'),
(5, 'posting cs  student events for testing ', '2019-05-17', '2019-05-08 17:20:37', '2019-05-08 17:20:37', 1, 10, 'CSE');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_query_answer`
--

CREATE TABLE `faculty_query_answer` (
  `answer_id` int(20) NOT NULL,
  `query_id` int(20) NOT NULL,
  `answer` text NOT NULL,
  `posted_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty_query_answer`
--

INSERT INTO `faculty_query_answer` (`answer_id`, `query_id`, `answer`, `posted_on`) VALUES
(1, 4, 'Answering now for this question', '2019-05-07 02:46:14'),
(2, 5, 'ggg', '2019-05-07 02:46:36'),
(3, 9, 'listen to the class properly.Don follow shivu', '2019-05-08 11:49:18');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_semisterlink`
--

CREATE TABLE `faculty_semisterlink` (
  `faculty_id` int(20) NOT NULL,
  `user_id` int(20) NOT NULL,
  `branch` varchar(20) NOT NULL,
  `section` varchar(10) NOT NULL,
  `semister` varchar(100) NOT NULL,
  `subject_code` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty_semisterlink`
--

INSERT INTO `faculty_semisterlink` (`faculty_id`, `user_id`, `branch`, `section`, `semister`, `subject_code`) VALUES
(5, 10, 'CSE', 'A', 'I', 'sco1'),
(6, 12, 'ISE', 'A', 'I', 'sco3');

-- --------------------------------------------------------

--
-- Table structure for table `genral_notice`
--

CREATE TABLE `genral_notice` (
  `gen_notice_id` int(20) NOT NULL,
  `notice_date` varchar(100) NOT NULL,
  `notice_description` varchar(100) NOT NULL,
  `branch` varchar(100) NOT NULL,
  `semister` varchar(100) NOT NULL,
  `notice_path` varchar(150) NOT NULL,
  `posted_by` varchar(100) NOT NULL,
  `posted_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `genral_notice`
--

INSERT INTO `genral_notice` (`gen_notice_id`, `notice_date`, `notice_description`, `branch`, `semister`, `notice_path`, `posted_by`, `posted_on`) VALUES
(1, '07-05-2019', 'Education workshop conducted in College by STAR INC', 'CSE,MCA', 'I', 'uploads/student.csv', '3', '2019-05-06 00:00:00'),
(2, '14-05-2012', 'Seminar ', 'CE,CSE', 'I', 'uploads/student.xlxs', '3', '2019-05-06 06:33:28'),
(3, '2019-05-16', 'Line With Custom Bullets', 'CSE', 'I', 'hod_uploads/CloudOnHire_Notes_Sqoop.pdf', '8', '2019-05-07 21:03:10'),
(4, '2019-05-15', 'Internals will going to start', 'CSE', 'I', 'hod_uploads/faq_-_cube.pdf', '8', '2019-05-08 17:31:32');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `gid` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `Longitude` varchar(200) NOT NULL,
  `Latitude` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `user_id` varchar(10) NOT NULL,
  `login_time` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`gid`, `username`, `Longitude`, `Latitude`, `status`, `user_id`, `login_time`) VALUES
(26, 'SHIVA', '12.9594098', ' 77.6468683', 'Active', '1', '2019-05-08 18:16:39'),
(37, 'SHIVA', '12.9594098', ' 77.6468683', 'Active', '1', '2019-05-08 18:26:24');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `SL_NO` int(50) NOT NULL,
  `User_Name` varchar(25) NOT NULL,
  `Password` varchar(25) NOT NULL,
  `role_id` int(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `DOB` varchar(50) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `phno` varchar(20) NOT NULL,
  `branch` varchar(100) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `created_date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`SL_NO`, `User_Name`, `Password`, `role_id`, `firstname`, `lastname`, `DOB`, `sex`, `phno`, `branch`, `email_id`, `created_date`) VALUES
(0, 'admin', 'admin', 1, 'HARSHITHA', 'VENKATESH', '07-03-2019', 'FEMALE', '1111111111', 'MCE', 'harshitha@gmail.com', '2019-04-17 12:59:39'),
(0, 'har', 'har', 2, 'HARSHITHA', 'V', '14-03-2019', 'FEMALE', '2222222222', 'MCI', 'harshitha@gmail.com', '2019-04-17 13:06:57'),
(0, 'almas', 'almas', 1, 'ALMAS', 'SYED', '14-03-2019', 'MALE', '3333333333', 'ISE', 'almas@gmail.com', '2019-04-17 13:12:22'),
(0, 'shivu', 'shivu', 2, 'SHIVA ', 'KUMAR', '28-02-2019', 'MALE', '6666666666', 'MCA', 'j@gmail.com', '2019-04-22 16:27:06'),
(0, 'SUSH', 'SUSH', 2, 'SUSHMITHA', 'V', '14-03-2019', 'FEMALE', '7777777777', 'MCN', 'x@gmail.com', '2019-04-22 16:32:53');

-- --------------------------------------------------------

--
-- Table structure for table `notes_upload_faculty`
--

CREATE TABLE `notes_upload_faculty` (
  `upload_id` int(20) NOT NULL,
  `semester` varchar(20) NOT NULL,
  `branch_code` varchar(20) NOT NULL,
  `subject_code` varchar(20) NOT NULL,
  `uploaded_path` varchar(100) NOT NULL,
  `uploaded_by` int(20) NOT NULL,
  `notes_title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notes_upload_faculty`
--

INSERT INTO `notes_upload_faculty` (`upload_id`, `semester`, `branch_code`, `subject_code`, `uploaded_path`, `uploaded_by`, `notes_title`) VALUES
(1, 'I', 'CSE', 'SCo1', 'uploads/text.xlsx', 3, 'subject1'),
(2, 'I', 'CSE', 'sco1', 'uploads/CloudOnHire_Notes_Pig.pdf', 4, 'An Example of a Google Bar Chart'),
(3, 'I', 'CSE', 'sco1', 'uploads/faq_-_cube.pdf', 4, 'Vertical Line Chart'),
(4, 'I', 'CSE', 'sco1', 'uploads/elms(1).sql', 10, 'notes upload testing');

-- --------------------------------------------------------

--
-- Table structure for table `notice_by_faculty`
--

CREATE TABLE `notice_by_faculty` (
  `notice_facid` int(20) NOT NULL,
  `event_id` int(11) NOT NULL,
  `semister` varchar(100) NOT NULL,
  `section` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notice_by_faculty`
--

INSERT INTO `notice_by_faculty` (`notice_facid`, `event_id`, `semister`, `section`) VALUES
(1, 3, 'I', 'A'),
(2, 4, 'I', 'A'),
(3, 5, 'I', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `SL_NO` int(11) NOT NULL,
  `role_name` varchar(500) NOT NULL,
  `role_id` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`SL_NO`, `role_name`, `role_id`) VALUES
(1, 'student', '1'),
(2, 'faculty', '2'),
(5, 'HOD(admin)', '3'),
(6, 'PLACEMENT_OFFICER', '4');

-- --------------------------------------------------------

--
-- Table structure for table `semister`
--

CREATE TABLE `semister` (
  `sem_id` int(100) NOT NULL,
  `sem` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semister`
--

INSERT INTO `semister` (`sem_id`, `sem`) VALUES
(1, 'I'),
(2, 'II'),
(3, 'III'),
(4, 'IV'),
(5, 'V'),
(6, 'VI'),
(7, 'VII'),
(8, 'VIII');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `student_firstname` varchar(100) NOT NULL,
  `student_lastname` varchar(100) NOT NULL,
  `student_usn` varchar(100) NOT NULL,
  `student_phnumber` varchar(100) NOT NULL,
  `student_branch` varchar(100) NOT NULL,
  `student_semester` varchar(100) NOT NULL,
  `student_section` varchar(100) NOT NULL,
  `created_date` varchar(11) NOT NULL,
  `updated_by` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `student_firstname`, `student_lastname`, `student_usn`, `student_phnumber`, `student_branch`, `student_semester`, `student_section`, `created_date`, `updated_by`) VALUES
(1, 'JHHJJ', 'JNK', 'NJKNKJNIK', '9999999999', 'MNT', 'I', 'A', '2019-04-23 ', 'admin'),
(2, 'Kushi', 'S', '1SI17MCA01', '1312369545', 'MCE', 'I', 'A', '', ''),
(3, 'Deepu', 'N', '1SI17MCA02', '1312369545', 'TE', 'I', 'A', '', ''),
(4, 'Druthi', 'Rai', '1SI17MCA03', '1111111111', 'EE', 'I', 'A', '', ''),
(5, 'Sanvi', 'D', '1SI17MCA04', '9873037039', 'CS', 'I', 'A', '', ''),
(6, 'Anu', 'M', '1SI17MCA05', '1234567890', 'MCA', 'I', 'A', '', ''),
(7, 'MANVI', 'RAI', '1SI17MCA06', '1234566789', 'MBA', 'I', 'A', '', ''),
(8, 'SYED', 'A', '1SI16MCA07', '1234566789', 'MCA', 'II', 'A', '', ''),
(9, 'ALMAS', 'S', '1SI16MCA08', '1234566789', 'MCA', 'II', 'A', '', ''),
(10, 'SHIVU', 'KUMAR', '1SI16MCA09', '1234566789', 'MCA', 'II', 'A', '', ''),
(11, 'LOHIT', 'KUMAR', '1SI16MCA10', '1234566789', 'MCA', 'II', 'A', '', ''),
(12, 'ZAID', 'KHAN', '1SI16MCA11', '1234566789', 'MCA', 'II', 'A', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `student_query`
--

CREATE TABLE `student_query` (
  `query_id` int(20) NOT NULL,
  `posted_by` int(20) NOT NULL,
  `query` text NOT NULL,
  `posted_to` int(11) NOT NULL,
  `posted_on` datetime NOT NULL,
  `branch` varchar(11) NOT NULL,
  `subject_code` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_query`
--

INSERT INTO `student_query` (`query_id`, `posted_by`, `query`, `posted_to`, `posted_on`, `branch`, `subject_code`) VALUES
(4, 1, '  \n aaaaaa        ', 3, '2019-05-06 14:35:17', 'CSE', 'sco1'),
(5, 1, ' insert5', 3, '2019-05-06 14:43:17', 'CSE', 'sco1'),
(6, 4, '', 3, '2019-05-07 00:14:45', 'CSE', 'sco1'),
(7, 9, '  query12 is posting', 4, '2019-05-07 13:44:13', 'CSE', 'sco1'),
(8, 1, 'Subject2 is posting\n         ', 10, '2019-05-07 13:53:45', 'CSE', 'sc02'),
(9, 1, '  \n         i don understand what u teach', 10, '2019-05-08 11:48:09', 'CSE', 'sco1');

-- --------------------------------------------------------

--
-- Table structure for table `student_table`
--

CREATE TABLE `student_table` (
  `stud_id` int(20) NOT NULL,
  `user_id` int(20) NOT NULL,
  `semister` varchar(20) NOT NULL,
  `usn` varchar(100) NOT NULL,
  `section` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_table`
--

INSERT INTO `student_table` (`stud_id`, `user_id`, `semister`, `usn`, `section`) VALUES
(2, 1, 'I', '4ps1-ec053', 'A'),
(3, 8, '', '', ''),
(4, 9, 'I', '23dfgdfg', ''),
(5, 17, 'I', '1mj11mca36', 'B'),
(6, 18, 'III', '234234zre', 'A'),
(7, 19, 'I', '23dfgdfg', 'A');

-- --------------------------------------------------------

--
-- Table structure for table `subject_master`
--

CREATE TABLE `subject_master` (
  `sub_id` int(100) NOT NULL,
  `subject_code` varchar(50) NOT NULL,
  `subject_name` varchar(50) NOT NULL,
  `semester` varchar(10) NOT NULL,
  `branch_code` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject_master`
--

INSERT INTO `subject_master` (`sub_id`, `subject_code`, `subject_name`, `semester`, `branch_code`) VALUES
(1, 'sco1', 'subject1', 'I', 'CSE'),
(2, 'sc02', 'subject2', 'II', 'CSE'),
(3, 'sco3', 'subject3', 'I', 'ISE');

-- --------------------------------------------------------

--
-- Table structure for table `user_mst`
--

CREATE TABLE `user_mst` (
  `user_id` int(20) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role_id` int(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile_num` bigint(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `branch` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_mst`
--

INSERT INTO `user_mst` (`user_id`, `user_name`, `password`, `role_id`, `email`, `mobile_num`, `status`, `dob`, `gender`, `branch`) VALUES
(1, 'SHIVAKUMARA', 'shivu', 1, 'aaa@gmail.com', 9292625238, 'active', '14-02-1992', 'MALE', 'CSE'),
(8, 'muruli', 'muruli', 3, 'cshod@gmail.com', 9696865963, 'active', '13-03-2019', 'MALE', 'CSE'),
(9, 'STUDENT12', 'student12', 1, 'fweee@gmail.com', 9292623230, 'active', '28-02-2019', 'FEMALE', 'CSE'),
(10, 'ARUN', 'arun', 2, 'fac@gmail.com', 5434543512, 'active', '07-05-2019', 'MALE', 'CSE'),
(11, 'KUMAR', 'kumar', 1, 'iii@gmail.com', 9292625231, 'inactive', '20-05-2019', 'MALE', 'CSE'),
(12, 'QQQ', 'qqq', 2, 'e@gmail.com', 2342342342, 'active', '08-05-2019', 'MALE', 'ISE'),
(13, 'AMAR', 'amar', 3, 'ise@gmail.com', 2112122121, 'active', '20-03-2019', 'MALE', 'ISE'),
(14, 'HODCS', 'hodcs', 3, 'hod@gmail.com', 9292625230, 'inactive', '14-02-2019', 'FEMALE', 'CSE'),
(15, 'AAAA', 'rrr', 3, 'hodis@gmail.com', 9292625230, 'active', '13-03-2019', 'FEMALE', 'ISE'),
(16, 'ECHOD', 'echod', 2, 'hodec@gmail.com', 969686596, 'inactive', '09-05-2019', 'FEMALE', 'ISE'),
(17, 'aaaa', 'aaaa', 4, 'pramod01111@gmail.com', 3453453453, 'active', '23-05-2019', 'MALE', 'ISE'),
(18, 'student', 'ZQ1HTzJ', 1, 'pe@gmail.com', 9292625230, 'inactive', '06-03-2019', 'MALE', 'CSE'),
(19, 'pramod', 'OjXhpWq', 1, 'pramod01111@gmail.com', 969686596, 'inactive', '06-03-2019', 'MALE', 'CSE');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `attendance_tracker`
--
ALTER TABLE `attendance_tracker`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `college_events_table`
--
ALTER TABLE `college_events_table`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faculty_query_answer`
--
ALTER TABLE `faculty_query_answer`
  ADD PRIMARY KEY (`answer_id`);

--
-- Indexes for table `faculty_semisterlink`
--
ALTER TABLE `faculty_semisterlink`
  ADD PRIMARY KEY (`faculty_id`);

--
-- Indexes for table `genral_notice`
--
ALTER TABLE `genral_notice`
  ADD PRIMARY KEY (`gen_notice_id`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`gid`);

--
-- Indexes for table `notes_upload_faculty`
--
ALTER TABLE `notes_upload_faculty`
  ADD PRIMARY KEY (`upload_id`);

--
-- Indexes for table `notice_by_faculty`
--
ALTER TABLE `notice_by_faculty`
  ADD PRIMARY KEY (`notice_facid`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`SL_NO`);

--
-- Indexes for table `semister`
--
ALTER TABLE `semister`
  ADD PRIMARY KEY (`sem_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `student_query`
--
ALTER TABLE `student_query`
  ADD PRIMARY KEY (`query_id`);

--
-- Indexes for table `student_table`
--
ALTER TABLE `student_table`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `subject_master`
--
ALTER TABLE `subject_master`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `user_mst`
--
ALTER TABLE `user_mst`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `attendance_tracker`
--
ALTER TABLE `attendance_tracker`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `college_events_table`
--
ALTER TABLE `college_events_table`
  MODIFY `event_id` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `faculty_query_answer`
--
ALTER TABLE `faculty_query_answer`
  MODIFY `answer_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `faculty_semisterlink`
--
ALTER TABLE `faculty_semisterlink`
  MODIFY `faculty_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `genral_notice`
--
ALTER TABLE `genral_notice`
  MODIFY `gen_notice_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `gid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT for table `notes_upload_faculty`
--
ALTER TABLE `notes_upload_faculty`
  MODIFY `upload_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `notice_by_faculty`
--
ALTER TABLE `notice_by_faculty`
  MODIFY `notice_facid` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `SL_NO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `semister`
--
ALTER TABLE `semister`
  MODIFY `sem_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `student_query`
--
ALTER TABLE `student_query`
  MODIFY `query_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `student_table`
--
ALTER TABLE `student_table`
  MODIFY `stud_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `subject_master`
--
ALTER TABLE `subject_master`
  MODIFY `sub_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `user_mst`
--
ALTER TABLE `user_mst`
  MODIFY `user_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
