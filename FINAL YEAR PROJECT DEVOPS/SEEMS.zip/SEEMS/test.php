<?php

session_start();

if(isset($_SESSION["UserName"]))

{

if((time() - $_SESSION['last_time']) > 500) // Time in Seconds

{

header("location:Index.php");

}

else

{

$_SESSION['last_time'] = time();

}

}

 

 

?>

<!DOCTYPE html>

                <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>

<!-- Include all compiled plugins (below), or include individual files as needed -->



<html lang="en">
<script src="assets/js/bootstrap.min.js"></script>
                <head>

                                <?php require_once("title_logo.php");?>

               

 

                                <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

                                <meta charset="utf-8" />

                                <title>Faculty Admin</title>

 

                                <meta name="description" content="Common form elements and layouts" />

                                <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />

 

                                <!-- bootstrap & fontawesome -->

                                <link rel="stylesheet" href="assets/css/bootstrap.min.css" />

                                <link rel="stylesheet" href="assets/font-awesome/4.5.0/css/font-awesome.min.css" />

 

                                <!-- page specific plugin styles -->

                                <link rel="stylesheet" href="assets/css/jquery-ui.custom.min.css" />

                                <link rel="stylesheet" href="assets/css/chosen.min.css" />

                                <link rel="stylesheet" href="assets/css/bootstrap-datepicker3.min.css" />

                                <link rel="stylesheet" href="assets/css/bootstrap-timepicker.min.css" />

                                <link rel="stylesheet" href="assets/css/daterangepicker.min.css" />

                                <link rel="stylesheet" href="assets/css/bootstrap-datetimepicker.min.css" />

                                <link rel="stylesheet" href="assets/css/bootstrap-colorpicker.min.css" />

 

                                <!-- text fonts -->

                                <link rel="stylesheet" href="assets/css/fonts.googleapis.com.css" />

 

                                <!-- ace styles -->

                                <link rel="stylesheet" href="assets/css/ace.min.css" class="ace-main-stylesheet" id="main-ace-style" />

 

                                <!--[if lte IE 9]>

                                                <link rel="stylesheet" href="assets/css/ace-part2.min.css" class="ace-main-stylesheet" />

                                <![endif]-->

                                <link rel="stylesheet" href="assets/css/ace-skins.min.css" />

                                <link rel="stylesheet" href="assets/css/ace-rtl.min.css" />

 

                                <!--[if lte IE 9]>

                                  <link rel="stylesheet" href="assets/css/ace-ie.min.css" />

                                <![endif]-->

 

                                <!-- inline styles related to this page -->

 

                                <!-- ace settings handler -->

                                <script src="assets/js/ace-extra.min.js"></script>

                                <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.4.0/animate.min.css" charset="UTF-8"></script>

 

 

<!DOCTYPE html>

<html lang="en">

                <head>

<style>

input[type="checkbox"]{

  width: 15px; /*Desired width*/

  height: 15px; /*Desired height*/

  cursor: pointer;

  appearance: none;

}

</style>              

               

 

                </head>

               

 

               

 

                <body class="no-skin">

                <?php require_once("faculty_Header.php");?>

 

                                <div class="main-container ace-save-state" id="main-container">

                                                <script type="text/javascript">

                                                                try{ace.settings.loadState('main-container')}catch(e){}

                                                </script>

                                                <div id="sidebar" class="sidebar responsive ace-save-state">

                                                                <script type="text/javascript">

                                                                                try{ace.settings.loadState('sidebar')}catch(e){}

                                                                </script>

 

                                                                <ul class="nav nav-list">

                                                                <li class="active">

                                                                                                <a href="Attendance.php">

                                                                                                                <i class="menu-icon fa fa-book "></i>

                                                                                                                Take attendance

                                                                               

                                                                                                </a>

 

                                                                                                <b class="arrow"></b>

                                                                                </li>

                                                                                <li class="">

                                                                                                <a href="subject.php">

                                                                                                                <i class="menu-icon fa fa-inbox "></i>

                                                                                                                Generate report

                                                                               

                                                                                                </a>

 

                                                                                                <b class="arrow"></b>

                                                                                </li>

                                                                               

                                                                               

                               

                                                                               

                                                                                <ul class="nav nav-list">

                                                                                <li class="">

                                                                                                <a href="student_report.php">

                                                                                                                <i class="menu-icon fa  fa-check-square-o "> </i>

                                                                                                                Student report

                                                                               

                                                                                                </a>

 

                                                                                                <b class="arrow"></b>

                                                                                </li>

 

                                                               

 

                                                               

                                                                               

                                                                </ul><!-- /.nav-list -->

</ul>

                                               

                                                </div>

 

                                                <div class="main-content">

                               

 

                                                                                                <div class="page-header">

                                                                                                                <h1>

                                                                                                                <b>        Take Attendance</b>

                                                                                                               

                                                                                                                </h1>

                                                                                                </div><!-- /.page-header -->

 

                                                                                                <div class="row">

                                                                                                                <div class="col-xs-10">

                                                                                                                                <!-- PAGE CONTENT BEGINS -->

                                                                                                                                <form class="form-horizontal" role="form" name="myForm" method="POST" action="attendance_process.php" onsubmit="return Validation()" >

                                                                                                                               

                                                                                                                                               

                                                                                                                                                <div class="form-group">

                                                                                                                               

                                                                                                                                                                <label class="col-sm-2 control-label no-padding-right" for="form-field-1"> Faculty</label>

 

                                                                                                                                                                <div class="col-sm-3">

                                                                                                                                                                                <input type="text" id="form-field-1" name="faculty" placeholder="Name" class="form-control" value=""/>

                                                                                                                                                                               

                                                                                                                                                                               

                                                                                                                                                                </div>

                                                                                                                                                                               

                                                                                                                                                               

                                                                                                                                                </div>

                                                                                                                                                               

                                                                                                                                                                                                                                                               

                                                                                                                                               

                                                                                                                                                                                                                               

                                                                                                               

                                                                                                                                <div class="form-group">

                                                                                                                                                                <label class="col-sm-2 control-label no-padding-right" for="form-field-1-1"> Semester </label>

                                                                                                                                <div class="col-sm-5"> 

                                                                                                                                                <select class="col-sm-7" name="semester" id='sem'>

                                                                                                                                                   <option value="0" selected>select..</option>

                                                                                                                                                    <option value="I">I</option>

                                                                                                                                                   <option value="II">II</option>

                                                                                               

                                                                                                                                                   <option value="III">III</option>

                                                                                                                                                   <option value="IV">IV</option>

                                                                                                                                   </select>

                                                                                                                                  

                                                                                                                               

                                                                                                                                </div>                  

                                                                                                                               

                                                                                                                </div>

                                                                                               

                                                                                                                            

                                                                                                                                                                                                       

                                                                                                                                <div class="form-group">

                                                                                                                                                                <label class="col-sm-2 control-label no-padding-right" for="form-field-1-1"> Section </label>

                                                                                                                                <div class="col-sm-5"> 

                                                                                                                                                <select class="col-sm-7" name="section" id='sec'>

                                                                                                                                                <option value="0" selected>select..</option>

                                                                                                                                                <option value="A">A</option>

                                                                                                                                                <option value="B">B</option>

                                                                                                                                                <option value="C">C</option>

                                                                                                                                                <option value="D">D</option>

                                                                                                                                               

                                                                                                                                </select>

                                                                                                                                               

                                                                                                                                </div>  

                              </div>                                                                                                                    

                                                                                                                               

                                                                                                                                <div class="form-group">

                                                                                                                                                                <label class="col-sm-2 control-label no-padding-right" for="form-field-1-1"> Subject Code </label>

                                                                                                                                <div class="col-sm-5"> 

                                                                                                                                                <select class="col-sm-7" name="subcode">

                                                                                                                                                <option value="0" selected>select..</option>

                                                                                                                                                <option value="16MAT30">16MAT30</option>

                                                                                                                                                <option value="16MS31">16MS31</option>

                                                                                                                                                <option value="16DS32">16DS32</option>

                                                                                                                                                <option value="16SE33">16SE33</option>

                                                                                                                                               

                                                                                                                                </select>

                                                                                                                                               

                                                                                                                                </div>                  

                                                                                                                </div>

                                                                               

                                                                                <div class="form-group">

                                                                                                                                                                <label class="col-sm-2 control-label no-padding-right" for="form-field-1-1"> Timings </label>

                                                                                                                                <div class="col-sm-5"> 

                                                                                                                                                <select class="col-sm-7" name="timings">

                                                                                                                                                <option value="0" selected>select..</option>

                                                                                                                                                <option value="8.30-9.30">8.30-9.30</option>

                                                                                                                                                <option value="9.30-10.30">9.30-10.30</option>

                                                                                                                                                <option value="10.30-11.30">10.30-11.30</option>

                                                                                                                                                <option value="11.30-12.30">11.30-12.30</option>

                                                                                                                                               

                                                                                                                                </select>

                                                                                                                                               

                                                                                                                                </div>

                                                                                                                </div>

                                                                                                               

                                                                                                                      

                                                                                 <div class="form-group">

                                                                                                                                                                <label class="col-sm-2 control-label no-padding-right" for="form-field-1-1">USN</label>

                                                                                                                <div class="col-sm-5"> 

                                                <table border=2><tr id='usn'/></table> <br>

                                   

                                                                                                                                </div>  

                                                                                                                </div>  

                                                                                                                <div class="form-group">

                                                                                                                                                                <label class="col-sm-2 control-label no-padding-right" for="form-field-1-1">Absenties USN </label>

                                                                                                                                                                <div class="col-sm-5"> 

                                                                                                                                                                                <textarea type="text" id="selectedtext" name="USN[]"></textarea><br>      

                                                                                                                                                                                </div>

                                                                                                                                </div>                  

 

                                                                                                                                <div class="form-group">

                                                                                                                                                                <label class="col-sm-2 control-label no-padding-right" for="form-field-1-1">Absenties Count</label>

                                                                                                                                                                <div class="col-sm-5">

                                                                                                                                                                                                <input type="text" id="count" name="count"/>                     

                                                                                                                                                                </div>

                                                                                                                                </div>                                                  

                                                                                                                               

                                                                                                                                <!--<div class="form-group">

                                                                                                                                                                <label class="col-sm-2 control-label no-padding-right" for="form-field-1-1"> USN </label>&nbsp;&nbsp;

                                                                                                                                <div class="col-sm-9"> 

                                                                                                                                                                <input type="checkbox" class="chkbx"  value="1SI17MCA02"/>  1SI17MCA02

                                                         <input type="checkbox" class="chkbx"  value="1SI17MCA12"/>  1SI17MCA12

                                                         <input type="checkbox" class="chkbx"  value="1SI17MCA21"/>  1SI17MCA21

                                                         <input type="checkbox" class="chkbx"  value="1SI17MCA31"/>  1SI17MCA31

                                                                                                                                                                                 <input type="checkbox" class="chkbx"  value="1SI17MCA41"/>  1SI17MCA41

                                                         <input type="checkbox" class="chkbx"  value="1SI17MCA51"/>  1SI17MCA51 <br>

                                     

                                                                                                                                                                                                  

                                 </div>                                                                                                                                                 

                                                                                </div>

                                                                                                                                                                               <div class="form-group">                                               

                                                                                                                                                                                                                <label class="col-sm-2 control-label no-padding-right" for="form-field-1-1"> Selected USN </label>

                                                                                                                                                                                                                <div class="col-sm-4">           

                                                                                                                                                                                                                <textarea type="text" id="selectedtext" name="USN[]" rows="1" cols="55"></textarea><br>

                                                                                                                                                                                                                </div>

                                                                                                                                            </div>

                                                                                                                                                                               

                                                                                                                                                                               

                                                                                                                                                                                <div class="form-group">                                               

                                                                                                                                                                                                                <label class="col-sm-2 control-label no-padding-right" for="form-field-1-1"> Absentives Count </label>

                                                                                                                                                                                                                <div class="col-sm-6">           

                                                                                                                                                                                                                <input type="text" name="count[]" id="count"   style='text-transform:uppercase'class="form-control" />       

                                                                                                                                                                                                                </div>

                                                                                                                                                                                                                               

                                                                                                                                                                                                                </div> -->

                                                                                                                                           

                                                                                                                                                                 <div class="col-md-offset-3 col-md-9">

                                                                                                                                                               

                                                                                                                                                                                <button class="btn btn-info "type="submit" name="submit">

                                                                                                                                                                                <i class="ace-icon fa fa-check bigger-110"></i>

                                                                                                                                                                                                Submit

                                                                                                                                                                                                </button>          

                                                                                                                                                               

                                                                                                               

                                                                                                                                                                                </div>

                                                                                                                               

                                                                                                                                                                               

                                                                                                                                                                                </div>

                                                                                                                                                                               

                                                                                                                                               

                                                                                                                </div><!-- /.col -->

                                                                                                                                                                </form>

                                                                                                </div><!-- /.row -->

                                                                                <a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">

                                                                <i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>

                                                </a>

                                                </div><!-- /.main-content -->

 

                               

 

                                                <a href="#" id="btn-scroll-up" class="btn-scroll-up btn btn-sm btn-inverse">

                                                                <i class="ace-icon fa fa-angle-double-up icon-only bigger-110"></i>

                                                </a>

                                </div><!-- /.main-container -->

                               

                               

                                <script src="assets/js/jquery-2.1.4.min.js"></script>

 

                                <!-- <![endif]-->

 

                                <!--[if IE]>

<script src="assets/js/jquery-1.11.3.min.js"></script>

<![endif]-->

                <script type="text/javascript">

                                                if('ontouchstart' in document.documentElement) document.write("<script src='assets/js/jquery.mobile.custom.min.js'>"+"<"+"/script>");

                                </script>

                               

                               

                                <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>

 

                                <script type="text/javascript">

              $(document).ready(function(){

                                               

                                                  $("#sec").change(function(){

                                                  var sem=document.getElementById("sem").value;

                                                  var sec=document.getElementById("sec").value;

                                                  $.post("usn.php",{sem:sem,sec:sec},function(data,status){

                                                               

                                                                  alert(data);

                                                                var obj=JSON.parse(data);

                                                                var i=0;

                                                                var usn=obj.student_usn;

                                                    $("#usn").empty();

                                                               

                                                                for(j=0;j<usn.length;j++)

                                                                {

                                                                $("#usn").append("<input type='checkbox' checked name='usn' class='chkbx' value="+usn[j]+" onchange=getValues("+i+","+"'"+usn[j]+"') id=usn"+i+"/>"+usn[j]);

                                                                  i++;

                                                                }

                                                                  })

                                                                  });

                                                  });

                                                 

</script>

                                                 

   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

   <script type="text/javascript">

 

                   

   $(document).ready(function() {

                                //$("#selectedtext").hide();

                               

                                var unchecked=new Array();

                               

                               

      

    });         

                   

</script>

 

<script  type="text/javascript">

var unchecked=new Array();

function getValues(a,value1){

               

                var counter=0;

                //alert(value1);

               

                var search_count1=0;

                               

                                for(var k=0;k<unchecked.length;k++)

                                {

                                                if(value1==unchecked[k])

                                                {

                                                                search_count1++;

                                                }

                                }

                                if(search_count1==0)

                                {

                unchecked.push(value1);

                                }

                //alert(unchecked.length);

               

 

                $("#selectedtext").empty();

                for(var i=0;i<unchecked.length;i++)

                {

                               

                               

                               

                                var aval=unchecked[i]+",";

                                $("#selectedtext").append(aval);

                               

                               

               

               

                $("#count").empty();

                $("#count").val(unchecked.length);

               

}

                               

}

 

</script>

 

 

 

 

<script  type="text/javascript">

                                function Validation()

                                {             

                                                var filter = /^[a-zA-Z ]*$/ ;

                                                var fname = document.myForm.faculty.value;

                                               

                                                //Faculty name

                                                if(fname == '')

                                                {

                                                                alert("Please Enter Your Name");

                                                                return false;

                                                }

                                               

                                                if(!filter.test(fname)){

                                                                alert("Please Enter Only Characters in faculty");

                                                                return false;

                                                }

                                                if(fname.length<4)

                                                {

                                                                alert("First name atleast four chracters ");

                                                                return false;

                                                }

 

                                                return (true);

                                }

                                               

          </script>

<div style="position: relative; text-align: right">

        <footer class="page-footer font-small blue" style="position: fixed; bottom: 0; width:100%;"><i><img src="images/navigem.png" width="7%" height="7%"/></img></i>&copy;All Rights Reserved.</footer>

        </div>

                               

                               

                               

                               

                               

                               

                </body>

 

</html>