<?php
$dbhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="sems";
$db=new mysqli("$dbhost","$dbuser","$dbpass","$dbname")
or die("could not connect to mysql");

?>