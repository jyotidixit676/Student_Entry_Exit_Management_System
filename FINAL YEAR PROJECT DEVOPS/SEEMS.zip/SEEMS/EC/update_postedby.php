<?php  
session_start();
$uid=$_SESSION['user_id'];
$branch=$_SESSION['branch'];

require_once('connection.php');


$result = $db->query("select * from events  order by id desc limit 1");
$row=mysqli_fetch_array($result);
$id=$row['id'];


$result1 = $db->query("update events set posted_by='$uid' , branch_code='$branch' where id='$id' ");

echo $result1; 

 
?>