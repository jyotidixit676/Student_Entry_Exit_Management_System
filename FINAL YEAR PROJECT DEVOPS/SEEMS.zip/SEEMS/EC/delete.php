<?php  

require_once('connection.php');


$id=$_GET['id'];



$result = $db->query("delete from events  where id='$id'");

if($result)
{
header('location:../academic_calender.php');
//require_once('../academic_calendar.php');
//require_once('C:\xampp\htdocs\sas\academic_calender.php');
}

 
?>