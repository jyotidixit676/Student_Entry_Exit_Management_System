<?php    

$usn=$_POST['usn'];

$semester=$_POST['semester'];
$display_string="";

require_once("config.php");
//$con=mysqli_connect("localhost","root","","smart_attendence");
//echo $usn;


//$sql2="select subcode,count(subcode)as tot_count from login group by subcode";//where subcode='$subcode'";
$count=1;
$sql2="SELECT subcode,count(subcode) as sss FROM `attendance_tracker` WHERE semester='$semester' group by subcode";
$result2=mysqli_query($conn,$sql2);
while($row2=mysqli_fetch_array($result2))
{
	$t=$row2['subcode'];
	$sql1="select * from attendance_tracker where subcode='$t' ";
	echo $sql1;
	

$result1=mysqli_query($conn,$sql1);

$usn_array="";

while($row1=mysqli_fetch_array($result1))
{
$usn_array=$usn_array.$row1['USN'];

}
$usnArray1 = explode(',', $usn_array);

//counting no of absent class
$count_absent=0;

for($i=0;$i<sizeof($usnArray1);$i++)
{
if(($usnArray1[$i])==$usn)
{
$count_absent=$count_absent+1;
}

}
$class_held=$row2['sss'];

$count_present=$class_held-$count_absent;
//echo 

$a=($count_present/$class_held)*100;
$test=$class_held.",".$count_present.",".$a;
//echo $test;
$b=round($a, 2);

if ($b >=85) $color = '#87B87F';
elseif ($b >=75) $color = '#6FB3E0';
elseif ($b <=75) $color = '#D15B47';
//echo "<span style=\"color: $color;\">$var</span>";

//echo "<span style=\"color: $color;\">$var</span>";


 $display_string .= "<tr><td>".$count."</td><td>".$row2['subcode']."</td><td>".$row2['sss']."</td><td>$count_absent</td><td><span style=\"color: $color;\">$b</td></span></</tr>";
$count++;

}


echo $display_string;

?>

