<?php    

$usn=$_POST['usn'];
$display_string="";

//require_once("config.php");
$con=mysqli_connect("localhost","root","","sinfo");
echo $usn;


//$sql2="select subcode,count(subcode)as tot_count from login group by subcode";//where subcode='$subcode'";
$count=1;
$sql2="SELECT subcode FROM `login` WHERE USN like 'usn%' group by `subcode`";
$result2=mysqli_query($con,$sql2);
while($row2=mysqli_fetch_array($result2))
{
 $display_string .= "<tr><td>".$count."</td><td><a  href=student_report.php?usn=".$row2['USN']."&sc=".$row2['subcode']."</td></tr>";
$count++;

}


echo $display_string;






?>

