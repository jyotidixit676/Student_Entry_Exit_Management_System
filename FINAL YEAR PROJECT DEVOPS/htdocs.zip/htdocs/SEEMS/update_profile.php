<?php
session_start();

$username=$_POST['username'];
$pwd=$_POST['pwd'];
$email=$_POST['email'];
$mobile_num=$_POST['mobile_num'];
$dob=$_POST['dob'];
$gender=$_POST["gender"];
$uid=$_SESSION['user_id'];



require_once("config.php");
$faculty_check="update user_mst set user_name='$username',password='$pwd',email='$email',mobile_num='$mobile_num',dob='$dob',gender='$gender' where user_id='$uid'";
$result_check=mysqli_query($conn,$faculty_check);

if($result_check)
{
	
	echo "Details updated Sucessfully";
}
else{
	
	echo "Details not updated Sucessfully";
}


?>
