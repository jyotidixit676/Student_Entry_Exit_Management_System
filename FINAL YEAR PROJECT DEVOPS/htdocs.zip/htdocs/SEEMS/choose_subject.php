<?php
session_start();

$branch=$_POST['branch'];
$sem=$_POST['sem'];
$subject=$_POST['subject'];
$section=$_POST['section'];

$user_id=$_SESSION['user_id'];

require_once("config.php");



$faculty_insert="insert into faculty_semisterlink(user_id,branch,section,semister,subject_code) values('$user_id','$branch','$section','$sem','$subject')";
$result_insert=mysqli_query($conn,$faculty_insert);


if($result_insert){
	echo "Subject  linked sucessfully";
}
else{
	
	echo "Error in Linking";
}



?>
