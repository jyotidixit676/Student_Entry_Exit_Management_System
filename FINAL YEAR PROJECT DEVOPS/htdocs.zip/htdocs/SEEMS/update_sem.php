<?php
session_start();

$sem=$_POST['sem'];

$uid=$_SESSION['user_id'];



require_once("config.php");
$faculty_check="update student_table set semister='$sem'  where user_id='$uid'";
$result_check=mysqli_query($conn,$faculty_check);

if($result_check)
{
	
	echo "Details updated Sucessfully";
}
else{
	
	echo "Details not updated Sucessfully";
}


?>
