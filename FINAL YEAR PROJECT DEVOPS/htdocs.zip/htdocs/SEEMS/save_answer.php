<?php
session_start();

$query_id=$_POST['qid'];
$answer=$_POST['answer'];


require_once("config.php");
$faculty_check="insert into faculty_query_answer(query_id,answer,posted_on) values('$query_id','$answer',NOW())";
$result_check=mysqli_query($conn,$faculty_check);


if($result_check){
	echo "Answer Posted sucessfully";
}
else{
	
	echo "Error in Post";
}



?>
