<?php
session_start();
require_once("config.php");
mysqli_set_charset($conn,"utf8");
// Get parameters from URL

$branch=$_SESSION['branch'];
// Start XML file, create parent node
$dom = new DOMDocument("1.0");
$node = $dom->createElement("markers");
$parnode = $dom->appendChild($node);
// Opens a connection to a mysqli server

// Search the rows in the markers table
//$query = "select ps.polling_booth_id,cs.cst_assembly_name,up.booth_name,ps.visited_status,ls.lattitude,ls.longitude,bv.next_visit,bv.visited_on,df.defer_status,df.defered_on,df.defer_till from polling_booth_mst ps join update_pasttrends up on ps.polling_booth_name=up.booth_name join cst_assembly_mst cs on ps.cst_id=cs.cst_id join latlong_master ls on ls.booth_id=ps.polling_booth_id  left join  booth_visit_table bv on ps.polling_booth_id=bv.polling_booth_id left join defer_pb df on df.booth_id=ps.polling_booth_id where  up.election_year ='$etype' and cs.cst_id='$assm' and ((up.vote_bjp / up.total_votes_polled)*100) between '$range1'  AND '$range2'";
//$query = "select ps.polling_station_id,ps.legistlative_Assembly,up.booth_name,ps.booth_visit_status,ls.lattitude,ls.longitude from polling_station_master ps join update_pasttrends up on ps.polling_name=up.booth_name join latlong_master ls on ls.booth_id=ps.polling_station_id";
$query ="select  u.user_id ,u.user_name,l.Longitude,L.Latitude,r.role_name,r.role_id,u.branch,l.login_time from location l left join user_mst u on l.user_id=u.user_id left join  role r on r.role_id=u.role_id where u.branch='$branch' and l.status='Active' and r.role_id in (1,2)";


$result = mysqli_query($conn,$query);

if (!$result) {
  die("Invalid query: " . mysqli_error());
}
header("Content-type: text/xml");
// Iterate through the rows, adding XML nodes for each
while ($row = mysqli_fetch_array($result)){
  $node = $dom->createElement("marker");
  $newnode = $parnode->appendChild($node);
   $newnode->setAttribute("user_id", $row['user_id']);
  $newnode->setAttribute("username", $row['user_name']);
   $newnode->setAttribute("role_id", $row['role_id']);
   $newnode->setAttribute("branch", $row['branch']);
  $newnode->setAttribute("lat", $row['Latitude']);
  $newnode->setAttribute("lng", $row['Longitude']);
   $newnode->setAttribute("role_name", $row['role_name']);
    $newnode->setAttribute("login_time", $row['login_time']);
  
   
}
echo $dom->saveXML();
?>