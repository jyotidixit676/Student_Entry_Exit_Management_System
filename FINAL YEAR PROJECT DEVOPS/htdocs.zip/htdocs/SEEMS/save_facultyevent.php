<?php
session_start();
$role_id=$_SESSION['role_id'];
$branch=$_POST['branch'];
$sem=$_POST['sem'];
$section=$_POST['section'];
$notice=$_POST['event'];
$notice_date=$_POST['event_date'];
$posted_by=$_SESSION['user_id'];


require_once("config.php");
$faculty_check="insert into events(title,date,created,modified,status,posted_by,branch_code) values('$notice','$notice_date',NOW(),NOW(),1,'$posted_by','$branch' )";
$result_check=mysqli_query($conn,$faculty_check);
$last_id = $conn->insert_id;

if($result_check){
	
	if($role_id==2)
	{
		$faculty_check1="insert into notice_by_faculty(event_id,semister,section) values('$last_id','$sem','$section')";
		$result_check1=mysqli_query($conn,$faculty_check1);
		if($result_check1){
		echo "Event created sucessfully";
		}
		
	}
	else{
		
	}
	
	
}
else{
	
	//echo "Error in Event Creation";
	echo"Error in event creation";
}



?>
