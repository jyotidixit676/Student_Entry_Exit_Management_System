<?php


$branch=$_POST['branch'];
$sem=$_POST['sem'];

//echo $user; echo "<br>";
//echo $pwd;
require_once("config.php");
$sql="select * from subject_master  where branch_code='$branch'  and semester='$sem' and subject_code not in (Select subject_code from faculty_semisterlink where branch='$branch' and semister='$sem')";
$result=mysqli_query($conn,$sql);
$display_string="";
while($row=mysqli_fetch_assoc($result)){
$display_string=$display_string."<option value=".$row['subject_code'].">".$row['subject_name'].	"-".$row['subject_code']."</option>";
	
}


echo $display_string;


?>
