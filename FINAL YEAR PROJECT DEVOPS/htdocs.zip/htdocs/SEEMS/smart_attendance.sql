-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2019 at 11:30 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_attendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `admin_id` int(11) NOT NULL,
  `admin_branch` varchar(100) NOT NULL,
  `admin_semester` varchar(100) NOT NULL,
  `admin_section` varchar(100) NOT NULL,
  `add_subject` varchar(100) NOT NULL,
  `subject_code` varchar(100) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`admin_id`, `admin_branch`, `admin_semester`, `admin_section`, `add_subject`, `subject_code`, `created_date`, `updated_by`) VALUES
(1, 'EC', 'Fourth', 'a', 'sdg', 'asdsaf', '0000-00-00 00:00:00', ''),
(2, 'BT', 'First', 'B', 'sdg', 'sdfd', '0000-00-00 00:00:00', ''),
(3, 'BA', 'Second', 'B', 'sdg', 'sdf', '2019-04-11 17:31:39', ''),
(4, 'CS', 'Sixth', 'C', 'dddd', 'f', '2019-04-12 11:44:33', 'admin'),
(5, 'CS', 'First', 'B', 'ffgf', 'sfdss', '2019-04-16 15:22:30', 'zzz'),
(6, 'BT', 'First', 'A', 'abcdd', 'sfdss', '2019-04-16 15:23:49', 'r'),
(7, 'CHE', 'Second', 'B', 'SF', 'SSF', '2019-04-16 15:28:43', 'r'),
(8, 'CHE', 'IV', 'B', 'sdg', 'ss', '2019-04-17 12:50:53', 'sss'),
(9, 'EC', 'V', 'B', 'science', 'ss', '2019-04-17 12:51:08', 'sss');

-- --------------------------------------------------------

--
-- Table structure for table `attendance_tracker`
--

CREATE TABLE `attendance_tracker` (
  `aid` int(11) NOT NULL,
  `faculty` varchar(200) NOT NULL,
  `semester` varchar(200) NOT NULL,
  `section` varchar(200) NOT NULL,
  `subcode` varchar(200) NOT NULL,
  `timings` varchar(200) NOT NULL,
  `USN` varchar(200) NOT NULL,
  `count` int(200) NOT NULL,
  `class_taken` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance_tracker`
--

INSERT INTO `attendance_tracker` (`aid`, `faculty`, `semester`, `section`, `subcode`, `timings`, `USN`, `count`, `class_taken`) VALUES
(1, 'sdfgsdfg', 'I', 'B', '16MS31', '9.30-10.30', '1f,', 1, '2019-04-17'),
(2, 'sdfsdf', 'I', 'B', '16MS31', '10.30-11.30', '1f,', 1, '2019-04-17'),
(3, 'sdfsdf', 'I', 'B', '16MS31', '10.30-11.30', '1f,', 1, '2019-04-17'),
(4, 'harshitha new', 'I', 'B', '16MS31', '8.30-9.30', '1f,', 1, '2019-04-17'),
(5, 'almas', 'I', 'A', '0', '0', '1si15mca10,', 1, '2019-04-17');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(300) NOT NULL,
  `branch_code` varchar(10) NOT NULL,
  `created_date` varchar(100) NOT NULL,
  `updated_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branch_id`, `branch_name`, `branch_code`, `created_date`, `updated_by`) VALUES
(0, 'abch', 'abc', '2019-03-08 15:10:00', 'admin'),
(1, 'B. Architecture', 'BA', '', ''),
(2, 'BE-Biotechnology', 'BT', '', ''),
(3, 'BE-Chemical Engineering', 'CHE', '', ''),
(4, 'BE-Civil Engineering', 'CE', '', ''),
(5, 'BE-Computer Science and Engineering', 'CS', '', ''),
(6, 'BE-Electrical and Electronics Engineering', 'EE', '', ''),
(7, 'BE-Electronics and Communication Engineering', 'EC', '', ''),
(8, 'BE-Industrial Engineering and Management', 'IE', '', ''),
(9, 'BE-Information Science and Engineering', 'ISE', '', ''),
(10, 'BE-Instrumentation Technology', 'IT', '', ''),
(11, 'BE-Mechanical Engineering', 'ME', '', ''),
(12, 'BE-Telecommunication Engineering', 'TE', '', ''),
(13, 'EKA Designs Pvt. Ltd.', 'EKA', '', ''),
(14, 'M.Tech Chemical Engineering', 'MCE', '', ''),
(15, 'M.Tech-Computer Integrated Manufacturing', 'MCI', '', ''),
(16, 'M.Tech-Computer Network Engineering', 'MCN', '', ''),
(17, 'M.tech-Computer Science and Engineering', 'MCS', '', ''),
(18, 'M.Tech-Digital Communication Engineering', 'MDC', '', ''),
(19, 'M.Tech-Manufacturing Sc. and Engineering Engineering', 'MMS', '', ''),
(20, 'M.Tech-Power Electronics', 'MPE', '', ''),
(21, 'M.Tech-Signal Processing', 'MSP', '', ''),
(22, 'M.Tech-Structural Engineering', 'MSE', '', ''),
(23, 'M.Tech-Thermal Power Engineering', 'MTP', '', ''),
(24, 'M.Tech-Transportation Engineering and Management', 'MTE', '', ''),
(25, 'M.Tech-Cyber Forensics and Information Security', 'MCI', '', ''),
(26, 'M.Tech-Nano Technology', 'MNT', '', ''),
(27, 'M.Tech-VLSI Design and Embedded Systems', 'MDE', '', ''),
(28, 'Master of Computer Applications', 'MCA', '', ''),
(29, 'Master of Business Administration', 'MBA', '', ''),
(30, 'PGDIP-Bioinformatics and Bigdata Analytics', 'BBA', '', ''),
(31, 'PGDIP-Bioinformatics and Rational Drug Design', 'BRD', '', ''),
(32, 'PGDIPBDA-Big Data Analytics', 'BDA', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `SL_NO` int(50) NOT NULL,
  `User_Name` varchar(25) NOT NULL,
  `Password` varchar(25) NOT NULL,
  `role_id` int(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `DOB` varchar(50) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `phno` varchar(20) NOT NULL,
  `branch` varchar(100) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `created_date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`SL_NO`, `User_Name`, `Password`, `role_id`, `firstname`, `lastname`, `DOB`, `sex`, `phno`, `branch`, `email_id`, `created_date`) VALUES
(0, 'admin', 'admin', 1, 'HARSHITHA', 'VENKATESH', '07-03-2019', 'FEMALE', '1111111111', 'MCE', 'harshitha@gmail.com', '2019-04-17 12:59:39'),
(0, 'har', 'har', 2, 'HARSHITHA', 'V', '14-03-2019', 'FEMALE', '2222222222', 'MCI', 'harshitha@gmail.com', '2019-04-17 13:06:57'),
(0, 'almas', 'almas', 1, 'ALMAS', 'SYED', '14-03-2019', 'MALE', '3333333333', 'ISE', 'almas@gmail.com', '2019-04-17 13:12:22');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `SL_NO` int(11) NOT NULL,
  `role_name` varchar(500) NOT NULL,
  `role_id` varchar(500) NOT NULL,
  `created_date` varchar(500) NOT NULL,
  `updated_by` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`SL_NO`, `role_name`, `role_id`, `created_date`, `updated_by`) VALUES
(1, 'admin', '1', '', ''),
(2, 'faculty', '2', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `student_firstname` varchar(100) NOT NULL,
  `student_lastname` varchar(100) NOT NULL,
  `student_usn` varchar(100) NOT NULL,
  `student_phnumber` varchar(100) NOT NULL,
  `student_branch` varchar(100) NOT NULL,
  `student_semester` varchar(100) NOT NULL,
  `student_section` varchar(100) NOT NULL,
  `created_date` varchar(11) NOT NULL,
  `updated_by` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `student_firstname`, `student_lastname`, `student_usn`, `student_phnumber`, `student_branch`, `student_semester`, `student_section`, `created_date`, `updated_by`) VALUES
(1, 'harshitha', 'v', 'w34dfg', '1312369545', 'MCE', 'Third', 'C', '0', '0'),
(2, 'harshitha', 'v', '1frdgdfgf', '1312369545', 'TE', 'Second', 'A', '0', '0'),
(3, 'harshitha', 'grytrur', '1f', '1111111111', 'EE', 'I', 'B', '2147483647', '0'),
(4, 'harshitha', 'd', '1frdgdfgf', '9873037039', 'CS', 'Sixth', 'B', '2147483647', '0'),
(5, 'harshitha', 'Venkatesh', '1si15mca10', '1234567890', 'MCA', 'Sixth', 'B', '2019-04-12 ', 'admin'),
(6, 'hhhh', 'hhhh', '1f', '9999999999', 'MCI', 'Second', 'A', '2019-04-16 ', 'r'),
(7, 'GH', 'HJ', 'H', '1111111111', 'TE', 'Third', 'B', '2019-04-16 ', 'r'),
(8, 'dfgdfg', 'dfgdfg', '234234zdfs', '2343232323', 'BA', 'IV', 'A', '2019-04-17 ', 'aaaa'),
(9, 'sdfgds', 'dfgd', 'dfdfs3435', '3434534534', 'BA', 'IV', 'A', '2019-04-17 ', 'aaaa'),
(10, 'harshitha', 'Venkatesh', '1si15mca10', '1312369545', 'TE', 'I', 'A', '2019-04-17 ', 'sss');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `attendance_tracker`
--
ALTER TABLE `attendance_tracker`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`SL_NO`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `attendance_tracker`
--
ALTER TABLE `attendance_tracker`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `SL_NO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
