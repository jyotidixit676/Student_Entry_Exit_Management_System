<?php
$dbhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="sems";
$conn=mysqli_connect("$dbhost","$dbuser","$dbpass","$dbname")
or die("could not connect to mysql");
if($conn)
{
//echo"<b>Connected sucessfully<b>";
}
?>