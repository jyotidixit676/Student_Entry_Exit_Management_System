<?php
	 include 'confignew2.php';
	 $response = array();
	// echo "success";
	 
	 // Check whether username or password is set from android	
     if(isset($_POST['username']) || isset($_POST['password']))
     {
		  // Innitialize Variable
		  $result='';
	   	  $email = $_POST['username'];
          $password = $_POST['password'];
		 // echo "success";
		  // Query database for row exist or not
          $sql = "SELECT user_id, user_name, password, role_id, email, mobile_num, status, dob, gender,branch FROM user_mst WHERE  email='$email' AND password='$password'";
		  //$sqla = "SELECT id, coursecode,coursename,classconduct,classAttend,percentage FROM attend";
		//echo"success";
		  //creating a query
	      $stmt = $conn->prepare($sql);
		  //$stmta = $conn->prepare($sqla);
	
	//executing the query 
	$stmt->execute();
	//$stmta->execute();
	
	//binding results to the query 
	$stmt->bind_result($user_id, $user_name, $password, $role_id, $email, $mobile_num, $status, $dob, $gender,$branch);
	//$stmta->bind_result($id, $coursecode, $coursename, $classconduct, $classAttend, $percentage);
	//$attend=array();
	//$tempa=array();
	//$register = array(); 
	$temp = array();
	//traversing through all the result 
	while($stmt->fetch()){
		
		$temp['user_id'] = $user_id; 
		$temp['user_name'] = $user_name; 
		$temp['password'] = $password; 
		$temp['role_id'] = $role_id; 
		$temp['email'] = $email; 
		$temp['mobile_num'] = $mobile_num; 
		$temp['status'] = $status; 
		$temp['dob'] = $dob; 
		$temp['gender'] = $gender; 
		$temp['branch'] = $branch; 
		
	$temp["msg"]="Success";
	}
		
	
	
	if(sizeof($temp)>0)
		 echo json_encode($temp);
	
	else
	
		 $response["msg"]="Failure";
  	
	 }
?>