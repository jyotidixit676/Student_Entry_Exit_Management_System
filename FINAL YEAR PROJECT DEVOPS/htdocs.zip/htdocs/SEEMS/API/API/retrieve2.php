<?php 
$servername = "localhost";
$username = "root";
$password = "N@v1g@m_mysql";
$dbname = "sems";
try {
    	$conn = mysqli_connect($servername, $username, $password,$dbname);
		
}
catch(PDOException $e)
    {
    	die("OOPs something went wrong");
    }
	
	//if(isset($_POST['usnno'])){
		// $usnno = $_POST['usnno'];
		 
	//creating a query
	$stmt = $conn->prepare("SELECT user_name,email, mobile_num, dob, gender,branch FROM user_mst ;");
	
	//executing the query 
	$stmt->execute();
	
	//binding results to the query 
	$stmt->bind_result( $user_name, $email, $mobile_num, $dob, $gender, $branch );
	
	$register = array(); 
	
	//traversing through all the result 
	while($stmt->fetch()){
		$temp = array();
		
		$temp['user_name'] = $user_name; 
		$temp['email'] = $email; 
		$temp['mobile_num'] = $mobile_num; 
		$temp['dob'] = $dob; 
		$temp['gender'] = $gender; 
		$temp['branch'] = $branch; 
		array_push($register, $temp);
	}
	
	//displaying the result in json format 
	echo json_encode($register);
	?>