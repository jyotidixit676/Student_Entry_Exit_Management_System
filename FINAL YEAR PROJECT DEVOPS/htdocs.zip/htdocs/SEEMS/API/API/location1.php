<?php
include('locationdb.php');
$response = array();
$params = json_decode(file_get_contents("php://input"));
	if((isset($params -> txt0))||(isset($params -> latitude))||(isset($params -> longitude)))
	{
	$uname = $params -> txt0;
	$Longitude = $params -> longitude;
	$Latitude = $params -> latitude;
	$status="Active";
	$sql12 = "select user_id from user_mst where user_name='$uname'";

		$result12 = mysqli_query($conn, $sql12);
		$row=mysqli_fetch_array($result12);
		$user_id=$row['user_id'];
		$sql = ("insert into location (user_id,username,Longitude,Latitude,status,login_time) values ('$user_id','$uname','$Longitude','$Latitude','$status',NOW())");
		$result1 = mysqli_query($conn, $sql);
		if($result1){
			$response['valid'] = true;
			$response['message'] = "Inserted successfully";
		}
		else{
			$response['valid'] = false;
			$response['message'] = "Insert Failure";
		
		}
 }	
 
 else{
	 $response['valid'] = false;
	 $response['message'] = "Please provide all the fields";
 }

 
echo json_encode($response);
?>