<?php

include('locationdb.php');

//echo "SUCCESS";
$response = array();
$params = json_decode(file_get_contents("php://input"));
	if(isset($params -> txt1))
	{
//	echo "SUCCESS";
	$uname = $params -> txt1;
	$status="InActive";
	$sql12 = "select user_id from user_mst where user_name='$uname'";
		$result12 = mysqli_query($conn, $sql12);
		$row=mysqli_fetch_array($result12);
		$user_id=$row['user_id'];
		$sql = "update location set status='$status' where user_id='$user_id'";
		//echo $sql;
		$result1 = mysqli_query($conn, $sql);
		
		if($result1){
			$response['valid'] = true;
			$response['message'] = "Updated successfully";
		}
		else{
			$response['valid'] = false;
			$response['message'] = "Update Failure";
		
		}
 }	
 
 else{
	 $response['valid'] = false;
	 $response['message'] = "Please provide all the fields";
 }

 
echo json_encode($response);
?>