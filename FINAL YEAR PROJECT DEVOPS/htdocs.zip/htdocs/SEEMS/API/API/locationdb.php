<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sems";
//echo"hi";
try {
    	$conn = mysqli_connect($servername, $username, $password,$dbname);
			//echo"hi";
}
catch(PDOException $e)
    {
    	die("OOPs something went wrong");
    }
 
?>