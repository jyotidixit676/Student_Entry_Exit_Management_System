<?php

$to = "pramod01111@gmail.com";
$subject = "test from localhost";
$msg = "I completely understand SMTP servers now!";
$headers = "From: pramod01111@gmail.com\nReply-To: pramod01111@gmail.com";
$config = "pramod01111@gmail.com";
mail("$to", "$subject", "$msg", "$headers", "$config");
echo "finishedfsdf!";
?>