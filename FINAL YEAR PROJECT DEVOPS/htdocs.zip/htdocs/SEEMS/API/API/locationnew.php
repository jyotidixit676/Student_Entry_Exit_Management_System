<?php

include('locationdb.php');

//echo "SUCCESS";
$response = array();
$params = json_decode(file_get_contents("php://input"));
 if((isset($params -> username))||(isset($params -> password)))
 {
	//echo "SUCCESS";
	$uname = $params -> username;
	$password = $params -> password;
	//$status="Active";
	//$Latitude = $params -> locationtext1;
	//echo $Longitude;
	//$latlong=(explode(',',$Longitude));
	//$lat=$latlong[0];
	//$long=$latlong[1];
	 $sql12 = "SELECT user_id, user_name, password, role_id, email, mobile_num, status, dob, gender,branch FROM user_mst WHERE  email='$uname' AND password='$password'";
	//$sql12 = "select user_id from user_mst where user_name='$uname'";
		//echo $sql12;
		$stmt = $conn->prepare($sql12);
		$stmt->execute();
		$stmt->bind_result($user_id, $user_name, $password, $role_id, $email, $mobile_num, $status, $dob, $gender,$branch);
		$temp = array();
		while($stmt->fetch()){
		
		$temp['user_id'] = $user_id; 
		$temp['user_name'] = $user_name; 
		$temp['password'] = $password; 
		$temp['role_id'] = $role_id; 
		$temp['email'] = $email; 
		$temp['mobile_num'] = $mobile_num; 
		$temp['status'] = $status; 
		$temp['dob'] = $dob; 
		$temp['gender'] = $gender; 
		$temp['branch'] = $branch; 
		
	$temp["msg"]="Success";
	//echo "successs";
	}
	if(sizeof($temp)>0)
		 echo json_encode($temp);
	
	else
	
		 $response["msg"]="Failure";
  	
	 }
	
	
 
 else{
	 $response['valid'] = false;
	 $response['message'] = "Please provide all the fields";
 }


?>