<?php
	include 'confignew2.php';
	$response = array();	
    //$params = json_decode(file_get_contents("php://input"));
 	if((isset($params -> username)) || (isset($params -> password)))
 	{
 		$uname = $params -> username;
		$password = $params -> password;	
        $sql = "SELECT user_id, user_name, password, role_id, email, mobile_num, status, dob, gender,branch FROM user_mst WHERE  user_name='$uname' AND password='$password'";
		//echo $sql;
		
		$stmt = $conn->prepare($sql);
		$stmt->execute();
		$stmt->bind_result($user_id, $user_name, $password, $role_id, $email, $mobile_num, $status, $dob, $gender,$branch);
		$temp = array();

		while($stmt->fetch()){
			$temp['user_id'] = $user_id; 
			$temp['user_name'] = $user_name; 
			$temp['password'] = $password; 
			$temp['role_id'] = $role_id; 
			$temp['email'] = $email; 
			$temp['mobile_num'] = $mobile_num; 
			$temp['status'] = $status; 
			$temp['dob'] = $dob; 
			$temp['gender'] = $gender; 
			$temp['branch'] = $branch;
			$response['msg'] = "Success";
		}
		if(sizeof($temp)>0)
			echo json_encode($temp);
		else{

			$response["msg"]="Login failed";
			echo json_encode($response);
		}	
	}
	else{
		$response["msg"]="Input fields missing";
		echo json_encode($response);
	}
?>
