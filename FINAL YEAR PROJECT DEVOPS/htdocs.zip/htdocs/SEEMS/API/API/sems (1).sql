-- phpMyAdmin SQL Dump
-- version 4.5.0.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2019 at 01:20 PM
-- Server version: 10.0.17-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sems`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `admin_id` int(11) NOT NULL,
  `admin_branch` varchar(100) NOT NULL,
  `admin_semester` varchar(100) NOT NULL,
  `admin_section` varchar(100) NOT NULL,
  `add_subject` varchar(100) NOT NULL,
  `subject_code` varchar(100) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`admin_id`, `admin_branch`, `admin_semester`, `admin_section`, `add_subject`, `subject_code`, `created_date`, `updated_by`) VALUES
(1, 'EC', 'Fourth', 'a', 'sdg', 'asdsaf', '0000-00-00 00:00:00', ''),
(2, 'BT', 'First', 'B', 'sdg', 'sdfd', '0000-00-00 00:00:00', ''),
(3, 'BA', 'Second', 'B', 'sdg', 'sdf', '2019-04-11 17:31:39', ''),
(4, 'CS', 'Sixth', 'C', 'dddd', 'f', '2019-04-12 11:44:33', 'admin'),
(5, 'CS', 'First', 'B', 'ffgf', 'sfdss', '2019-04-16 15:22:30', 'zzz'),
(6, 'BT', 'First', 'A', 'abcdd', 'sfdss', '2019-04-16 15:23:49', 'r'),
(7, 'CHE', 'Second', 'B', 'SF', 'SSF', '2019-04-16 15:28:43', 'r'),
(8, 'CHE', 'IV', 'B', 'sdg', 'ss', '2019-04-17 12:50:53', 'sss'),
(9, 'EC', 'V', 'B', 'science', 'ss', '2019-04-17 12:51:08', 'sss'),
(10, 'CE', 'III', 'A', 'GGG', 'GGG', '2019-04-22 14:39:41', 'admin'),
(11, 'CE', 'II', 'A', 'SCIENCE', 'SCI', '2019-04-22 16:25:29', 'admin'),
(12, 'MCA', 'II', 'A', 'DATA', 'DS', '2019-04-23 11:52:04', 'admin'),
(13, 'CS', 'I', 'A', 'CPROGRAM', 'MCA', '2019-04-23 13:10:37', 'admin'),
(14, 'BA', 'II', 'A', 'CPP', 'MNHH', '2019-04-23 16:15:51', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `attendance_tracker`
--

CREATE TABLE `attendance_tracker` (
  `aid` int(11) NOT NULL,
  `faculty` varchar(200) NOT NULL,
  `semester` varchar(200) NOT NULL,
  `section` varchar(200) NOT NULL,
  `subcode` varchar(200) NOT NULL,
  `timings` varchar(200) NOT NULL,
  `USN` varchar(200) NOT NULL,
  `count` int(200) NOT NULL,
  `class_taken` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance_tracker`
--

INSERT INTO `attendance_tracker` (`aid`, `faculty`, `semester`, `section`, `subcode`, `timings`, `USN`, `count`, `class_taken`) VALUES
(1, 'hard', 'I', 'A', 'sdfd', '10.30-11.30', 'NJKNKJNIK,', 1, '2019-04-29'),
(2, 'harq', 'I', 'A', 'sdfd', '0', 'NJKNKJNIK,', 2, '2019-05-03'),
(3, 'harer', 'I', 'A', 'asdsaf', '8.30-9.30', '1SI17MCA01,1SI17MCA02,', 2, '2019-05-03'),
(4, 'haras', 'I', 'A', 'asdsaf', '9.30-10.30', 'NJKNKJNIK,1SI17MCA01,1SI17MCA02,1SI17MCA03,1SI17MCA04,', 5, '2019-05-03');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(300) NOT NULL,
  `branch_code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branch_id`, `branch_name`, `branch_code`) VALUES
(1, 'COMPUTER_SCIENCE_AND_ENGINEERING', 'CSE'),
(2, 'INFORMATION_SCIENCE_AND_ENGINEERING', 'ISE'),
(3, 'ELECTRICAL_AND_ELECTRONICS_ENGINEERING', 'EEE'),
(4, 'ELECTRONICS_AND_COMMUNICATION_ENGINEERING', 'ECE'),
(5, 'CIVIL_ENGINEERING', 'CIVIL'),
(6, 'MECHANICAL_ENGINEERING', 'ME'),
(7, 'BIOTECHNOLOGY', 'BT'),
(8, 'PLACEMENTS', 'PLACEMENTS'),
(9, 'MANAGEMENT', 'MGMT');

-- --------------------------------------------------------

--
-- Table structure for table `college_events_table`
--

CREATE TABLE `college_events_table` (
  `event_id` int(20) NOT NULL,
  `event_name` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `event_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `faculty_query_answer`
--

CREATE TABLE `faculty_query_answer` (
  `answer_id` int(20) NOT NULL,
  `query_id` int(20) NOT NULL,
  `answer` text NOT NULL,
  `posted_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `faculty_semisterlink`
--

CREATE TABLE `faculty_semisterlink` (
  `faculty_id` int(20) NOT NULL,
  `user_id` int(20) NOT NULL,
  `branch` varchar(20) NOT NULL,
  `semister` varchar(100) NOT NULL,
  `subject_code` varchar(100) NOT NULL,
  `academic_year` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `faculty_semisterlink`
--

INSERT INTO `faculty_semisterlink` (`faculty_id`, `user_id`, `branch`, `semister`, `subject_code`, `academic_year`) VALUES
(2, 3, 'CSE', 'I', 'sco1', '2018-19');

-- --------------------------------------------------------

--
-- Table structure for table `genral_notice`
--

CREATE TABLE `genral_notice` (
  `gen_notice_id` int(20) NOT NULL,
  `notice_title` int(100) NOT NULL,
  `notice_description` int(100) NOT NULL,
  `brach` varchar(100) NOT NULL,
  `semister` varchar(100) NOT NULL,
  `posted_by` varchar(100) NOT NULL,
  `posted_on` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `SL_NO` int(50) NOT NULL,
  `User_Name` varchar(25) NOT NULL,
  `Password` varchar(25) NOT NULL,
  `role_id` int(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `DOB` varchar(50) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `phno` varchar(20) NOT NULL,
  `branch` varchar(100) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `created_date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`SL_NO`, `User_Name`, `Password`, `role_id`, `firstname`, `lastname`, `DOB`, `sex`, `phno`, `branch`, `email_id`, `created_date`) VALUES
(0, 'admin', 'admin', 1, 'HARSHITHA', 'VENKATESH', '07-03-2019', 'FEMALE', '1111111111', 'MCE', 'harshitha@gmail.com', '2019-04-17 12:59:39'),
(0, 'har', 'har', 2, 'HARSHITHA', 'V', '14-03-2019', 'FEMALE', '2222222222', 'MCI', 'harshitha@gmail.com', '2019-04-17 13:06:57'),
(0, 'almas', 'almas', 1, 'ALMAS', 'SYED', '14-03-2019', 'MALE', '3333333333', 'ISE', 'almas@gmail.com', '2019-04-17 13:12:22'),
(0, 'shivu', 'shivu', 2, 'SHIVA ', 'KUMAR', '28-02-2019', 'MALE', '6666666666', 'MCA', 'j@gmail.com', '2019-04-22 16:27:06'),
(0, 'SUSH', 'SUSH', 2, 'SUSHMITHA', 'V', '14-03-2019', 'FEMALE', '7777777777', 'MCN', 'x@gmail.com', '2019-04-22 16:32:53');

-- --------------------------------------------------------

--
-- Table structure for table `notes_upload_faculty`
--

CREATE TABLE `notes_upload_faculty` (
  `upload_id` int(20) NOT NULL,
  `semester` varchar(20) NOT NULL,
  `branch` varchar(20) NOT NULL,
  `subject_code` varchar(20) NOT NULL,
  `uploaded_path` varchar(100) NOT NULL,
  `uploaded_by` int(20) NOT NULL,
  `notes_title` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `notice_by_faculty`
--

CREATE TABLE `notice_by_faculty` (
  `notice_facid` int(20) NOT NULL,
  `notice_description` varchar(200) NOT NULL,
  `notice_date` date NOT NULL,
  `branch` varchar(100) NOT NULL,
  `semister` varchar(100) NOT NULL,
  `section` varchar(100) NOT NULL,
  `posted_by` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `SL_NO` int(11) NOT NULL,
  `role_name` varchar(500) NOT NULL,
  `role_id` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`SL_NO`, `role_name`, `role_id`) VALUES
(1, 'student', '1'),
(2, 'faculty', '2');

-- --------------------------------------------------------

--
-- Table structure for table `semister`
--

CREATE TABLE `semister` (
  `sem_id` int(100) NOT NULL,
  `sem` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `semister`
--

INSERT INTO `semister` (`sem_id`, `sem`) VALUES
(1, 'I'),
(2, 'II');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `student_firstname` varchar(100) NOT NULL,
  `student_lastname` varchar(100) NOT NULL,
  `student_usn` varchar(100) NOT NULL,
  `student_phnumber` varchar(100) NOT NULL,
  `student_branch` varchar(100) NOT NULL,
  `student_semester` varchar(100) NOT NULL,
  `student_section` varchar(100) NOT NULL,
  `created_date` varchar(11) NOT NULL,
  `updated_by` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `student_firstname`, `student_lastname`, `student_usn`, `student_phnumber`, `student_branch`, `student_semester`, `student_section`, `created_date`, `updated_by`) VALUES
(1, 'JHHJJ', 'JNK', 'NJKNKJNIK', '9999999999', 'MNT', 'I', 'A', '2019-04-23 ', 'admin'),
(2, 'Kushi', 'S', '1SI17MCA01', '1312369545', 'MCE', 'I', 'A', '', ''),
(3, 'Deepu', 'N', '1SI17MCA02', '1312369545', 'TE', 'I', 'A', '', ''),
(4, 'Druthi', 'Rai', '1SI17MCA03', '1111111111', 'EE', 'I', 'A', '', ''),
(5, 'Sanvi', 'D', '1SI17MCA04', '9873037039', 'CS', 'I', 'A', '', ''),
(6, 'Anu', 'M', '1SI17MCA05', '1234567890', 'MCA', 'I', 'A', '', ''),
(7, 'MANVI', 'RAI', '1SI17MCA06', '1234566789', 'MBA', 'I', 'A', '', ''),
(8, 'SYED', 'A', '1SI16MCA07', '1234566789', 'MCA', 'II', 'A', '', ''),
(9, 'ALMAS', 'S', '1SI16MCA08', '1234566789', 'MCA', 'II', 'A', '', ''),
(10, 'SHIVU', 'KUMAR', '1SI16MCA09', '1234566789', 'MCA', 'II', 'A', '', ''),
(11, 'LOHIT', 'KUMAR', '1SI16MCA10', '1234566789', 'MCA', 'II', 'A', '', ''),
(12, 'ZAID', 'KHAN', '1SI16MCA11', '1234566789', 'MCA', 'II', 'A', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `student_query`
--

CREATE TABLE `student_query` (
  `query_id` int(20) NOT NULL,
  `posted_by` int(20) NOT NULL,
  `query` text NOT NULL,
  `posted_to` int(11) NOT NULL,
  `posted_on` datetime NOT NULL,
  `branch` varchar(11) NOT NULL,
  `subject_code` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_query`
--

INSERT INTO `student_query` (`query_id`, `posted_by`, `query`, `posted_to`, `posted_on`, `branch`, `subject_code`) VALUES
(1, 1, '  pppppp\n         ', 22, '2019-05-06 14:29:35', '0', '0'),
(2, 1, '  sssss\n         ', 22, '2019-05-06 14:30:16', '0', '0'),
(3, 1, '  insert1\n         ', 3, '2019-05-06 14:32:33', '0', '0'),
(4, 1, '  \n aaaaaa        ', 3, '2019-05-06 14:35:17', 'CSE', 'sco1'),
(5, 1, ' insert5', 3, '2019-05-06 14:43:17', 'CSE', 'sco1');

-- --------------------------------------------------------

--
-- Table structure for table `student_table`
--

CREATE TABLE `student_table` (
  `stud_id` int(20) NOT NULL,
  `user_id` int(20) NOT NULL,
  `semister` varchar(20) NOT NULL,
  `usn` varchar(100) NOT NULL,
  `section` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subject_master`
--

CREATE TABLE `subject_master` (
  `sub_id` int(100) NOT NULL,
  `subject_code` varchar(50) NOT NULL,
  `subject_name` varchar(50) NOT NULL,
  `branch_code` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject_master`
--

INSERT INTO `subject_master` (`sub_id`, `subject_code`, `subject_name`, `branch_code`) VALUES
(1, 'sco1', 'subject1', 'CSE');

-- --------------------------------------------------------

--
-- Table structure for table `user_mst`
--

CREATE TABLE `user_mst` (
  `user_id` int(20) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role_id` int(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile_num` bigint(11) NOT NULL,
  `status` varchar(20) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `branch` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_mst`
--

INSERT INTO `user_mst` (`user_id`, `user_name`, `password`, `role_id`, `email`, `mobile_num`, `status`, `dob`, `gender`, `branch`) VALUES
(1, 'SHIVA', 'shiva', 1, 'aaa@gmail.com', 9292625230, 'active', '0000-00-00', 'MALE', 'CSE'),
(2, 'QQQQ', 'qqqq', 1, '$pe@gmail.com', 9035296140, 'inactive', '14-02-2019', 'MALE', 'TE'),
(3, 'QWQW', 'qwqw', 2, '$peee@gmail.com', 2323323242, 'inactive', '12-02-2019', 'MALE', 'EEE'),
(4, 'FACULTY', 'faculty', 1, 'pe@gmail.com', 9292625230, 'active', '28-02-2019', 'MALE', 'CSE');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `attendance_tracker`
--
ALTER TABLE `attendance_tracker`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `branch`
--
ALTER TABLE `branch`
  ADD PRIMARY KEY (`branch_id`);

--
-- Indexes for table `college_events_table`
--
ALTER TABLE `college_events_table`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `faculty_query_answer`
--
ALTER TABLE `faculty_query_answer`
  ADD PRIMARY KEY (`answer_id`);

--
-- Indexes for table `faculty_semisterlink`
--
ALTER TABLE `faculty_semisterlink`
  ADD PRIMARY KEY (`faculty_id`);

--
-- Indexes for table `genral_notice`
--
ALTER TABLE `genral_notice`
  ADD PRIMARY KEY (`gen_notice_id`);

--
-- Indexes for table `notes_upload_faculty`
--
ALTER TABLE `notes_upload_faculty`
  ADD PRIMARY KEY (`upload_id`);

--
-- Indexes for table `notice_by_faculty`
--
ALTER TABLE `notice_by_faculty`
  ADD PRIMARY KEY (`notice_facid`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`SL_NO`);

--
-- Indexes for table `semister`
--
ALTER TABLE `semister`
  ADD PRIMARY KEY (`sem_id`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `student_query`
--
ALTER TABLE `student_query`
  ADD PRIMARY KEY (`query_id`);

--
-- Indexes for table `student_table`
--
ALTER TABLE `student_table`
  ADD PRIMARY KEY (`stud_id`);

--
-- Indexes for table `subject_master`
--
ALTER TABLE `subject_master`
  ADD PRIMARY KEY (`sub_id`);

--
-- Indexes for table `user_mst`
--
ALTER TABLE `user_mst`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `attendance_tracker`
--
ALTER TABLE `attendance_tracker`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `college_events_table`
--
ALTER TABLE `college_events_table`
  MODIFY `event_id` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `faculty_query_answer`
--
ALTER TABLE `faculty_query_answer`
  MODIFY `answer_id` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `faculty_semisterlink`
--
ALTER TABLE `faculty_semisterlink`
  MODIFY `faculty_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `genral_notice`
--
ALTER TABLE `genral_notice`
  MODIFY `gen_notice_id` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `notes_upload_faculty`
--
ALTER TABLE `notes_upload_faculty`
  MODIFY `upload_id` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `notice_by_faculty`
--
ALTER TABLE `notice_by_faculty`
  MODIFY `notice_facid` int(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `SL_NO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `semister`
--
ALTER TABLE `semister`
  MODIFY `sem_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `student_query`
--
ALTER TABLE `student_query`
  MODIFY `query_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `student_table`
--
ALTER TABLE `student_table`
  MODIFY `stud_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `subject_master`
--
ALTER TABLE `subject_master`
  MODIFY `sub_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `user_mst`
--
ALTER TABLE `user_mst`
  MODIFY `user_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
