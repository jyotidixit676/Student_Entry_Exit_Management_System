<?php
extract($_POST);


function password_generate($chars) 
{
  $data = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
  return substr(str_shuffle($data), 0, $chars);
}
 // echo password_generate(7)."\n";
  $ppp=password_generate(7);
  echo $ppp;

if(isset($sendmail))
{
	
    $subject ="Successfully Registered to SEEMS";
	$from="seems.cse4@gmail.com";
	//$message =$name." ".$mobile." ".$query;
	$message="Congratulations!!! \n".
	"A Very Special Welcome to $name, Thank you for joining Sapthagiri SEEMS. \n".
   "Your registration process is successfull. Please use the below details to login to the system. \n".
        "Username: $name \n".
        "Password: $ppp \n".
		"Please login to the system for further use.";

   $headers = "From:".$from;
    mail($email,$subject,$message,$headers);
  
	echo "<h3 align='center'>Mail Sent Successfully</h3>";
}	
 
?>
 
<html>
<head>
	<title>Mail function in php - Phptpoint</title>
</head>
<body>
<form method="post">
 <table align="center" border="1">
	<Tr>
	<th>Enter Your name</th>
	<td><input type="text" name="name"/></td>
	</tr>
	<tr>
		<th>Enter Your mobile</th>
		<td><input type="text" name="mobile"/></td>
	</tr>	
	<tr>
		<th>Enter Your email</th>
		<td><input type="email" name="email"/></td>
	</tr>
	
	<tr>
		<th>Enter Your Query</th>
		<td><textarea name="query"></textarea></td>
	</tr>
		
	
	<tr>
		<td align="center" colspan="2">
		<input type="submit" value="Send Mail" name="sendmail"/>
		
	</tr>
	</table>	
</form>
</body>
</html>