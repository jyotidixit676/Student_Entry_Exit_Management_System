<?php
session_start();
 if(isset($_FILES['file'])){
	 require_once("config.php");
$branch=$_POST['branch'];
$sem=$_POST['sem'];

$fid=$_SESSION['user_id'];
$title=$_POST['title'];
$date=$_POST['date1'];
$target_dir = "hod_uploads/";
$target_file = $target_dir . basename($_FILES["file"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
echo $target_file;
// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}
// Check file size

// Allow certain file formats

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["file"]["name"]). " has been uploaded.";
		
		$sqlinsert="insert into  genral_notice(notice_date,notice_description,branch,semister,notice_path,posted_by,posted_on) values('$date','$title','$branch','$sem','$target_file','$fid',NOW())";
		
		$result=mysqli_query($conn,$sqlinsert);
		if($result){
		header("Location:a_notice.php");
		}
		
		
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
	
	
	
	
	
}
 }




?>
