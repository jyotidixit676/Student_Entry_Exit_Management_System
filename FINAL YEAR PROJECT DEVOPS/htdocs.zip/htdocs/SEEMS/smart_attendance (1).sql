-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 23, 2019 at 07:27 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smart_attendance`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `admin_id` int(11) NOT NULL,
  `admin_branch` varchar(100) NOT NULL,
  `admin_semester` varchar(100) NOT NULL,
  `admin_section` varchar(100) NOT NULL,
  `add_subject` varchar(100) NOT NULL,
  `subject_code` varchar(100) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`admin_id`, `admin_branch`, `admin_semester`, `admin_section`, `add_subject`, `subject_code`, `created_date`, `updated_by`) VALUES
(1, 'EC', 'Fourth', 'a', 'sdg', 'asdsaf', '0000-00-00 00:00:00', ''),
(2, 'BT', 'First', 'B', 'sdg', 'sdfd', '0000-00-00 00:00:00', ''),
(3, 'BA', 'Second', 'B', 'sdg', 'sdf', '2019-04-11 17:31:39', ''),
(4, 'CS', 'Sixth', 'C', 'dddd', 'f', '2019-04-12 11:44:33', 'admin'),
(5, 'CS', 'First', 'B', 'ffgf', 'sfdss', '2019-04-16 15:22:30', 'zzz'),
(6, 'BT', 'First', 'A', 'abcdd', 'sfdss', '2019-04-16 15:23:49', 'r'),
(7, 'CHE', 'Second', 'B', 'SF', 'SSF', '2019-04-16 15:28:43', 'r'),
(8, 'CHE', 'IV', 'B', 'sdg', 'ss', '2019-04-17 12:50:53', 'sss'),
(9, 'EC', 'V', 'B', 'science', 'ss', '2019-04-17 12:51:08', 'sss'),
(10, 'CE', 'III', 'A', 'GGG', 'GGG', '2019-04-22 14:39:41', 'admin'),
(11, 'CE', 'II', 'A', 'SCIENCE', 'SCI', '2019-04-22 16:25:29', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `attendance_tracker`
--

CREATE TABLE `attendance_tracker` (
  `aid` int(11) NOT NULL,
  `faculty` varchar(200) NOT NULL,
  `semester` varchar(200) NOT NULL,
  `section` varchar(200) NOT NULL,
  `subcode` varchar(200) NOT NULL,
  `timings` varchar(200) NOT NULL,
  `USN` varchar(200) NOT NULL,
  `count` int(200) NOT NULL,
  `class_taken` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attendance_tracker`
--

INSERT INTO `attendance_tracker` (`aid`, `faculty`, `semester`, `section`, `subcode`, `timings`, `USN`, `count`, `class_taken`) VALUES
(1, 'sdfgsdfg', 'I', 'B', '16MS31', '9.30-10.30', '1f,', 1, '2019-04-17'),
(2, 'sdfsdf', 'I', 'B', '16MS31', '10.30-11.30', '1f,', 1, '2019-04-17'),
(3, 'sdfsdf', 'I', 'B', '16MS31', '10.30-11.30', '1f,', 1, '2019-04-17'),
(4, 'harshitha new', 'I', 'B', '16MS31', '8.30-9.30', '1f,', 1, '2019-04-17'),
(5, 'almas', 'I', 'A', '0', '0', '1si15mca10,', 1, '2019-04-17'),
(6, 'HARNN', 'I', 'A', '16MAT30', '9.30-10.30', '', 1, '2019-04-22'),
(7, 'SHIVU', 'II', 'A', '0', '0', '', 0, '2019-04-22'),
(8, 'SHIVU', 'II', 'B', '0', '0', '', 2, '2019-04-22'),
(9, 'SUSH', 'II', 'A', '16MS31', '11.30-12.30', '', 1, '2019-04-22'),
(10, 'SUSH A', 'II', 'A', '16MS31', '8.30-9.30', '', 1, '2019-04-22'),
(11, 'SUSH B', 'I', 'A', '16MAT30', '8.30-9.30', '', 1, '2019-04-22'),
(12, 'SUSH', 'I', 'A', '16MAT30', '9.30-10.30', '', 1, '2019-04-22'),
(13, 'admin', 'I', 'B', '16MAT30', '9.30-10.30', '1f,', 1, '2019-04-22'),
(14, 'admin', 'I', 'B', '16MAT30', '9.30-10.30', '1f,', 1, '2019-04-22'),
(15, 'hars', 'I', 'A', '16MS31', '10.30-11.30', '1si15mca10,', 1, '2019-04-22'),
(16, 'hars', 'I', 'A', '16MS31', '10.30-11.30', '1si15mca10,', 1, '2019-04-22'),
(17, 'harr', 'II', 'A', '0', '0', '1SI16MCA45,', 1, '2019-04-22'),
(18, 'harr', 'II', 'A', '0', '0', '1SI16MCA45,', 1, '2019-04-22'),
(19, 'har as', 'I', 'A', '0', '0', '1si15mca10,', 1, '2019-04-22');

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE `branch` (
  `branch_id` int(11) NOT NULL,
  `branch_name` varchar(300) NOT NULL,
  `branch_code` varchar(10) NOT NULL,
  `created_date` varchar(100) NOT NULL,
  `updated_by` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`branch_id`, `branch_name`, `branch_code`, `created_date`, `updated_by`) VALUES
(0, 'abch', 'abc', '2019-03-08 15:10:00', 'admin'),
(1, 'B. Architecture', 'BA', '', ''),
(2, 'BE-Biotechnology', 'BT', '', ''),
(3, 'BE-Chemical Engineering', 'CHE', '', ''),
(4, 'BE-Civil Engineering', 'CE', '', ''),
(5, 'BE-Computer Science and Engineering', 'CS', '', ''),
(6, 'BE-Electrical and Electronics Engineering', 'EE', '', ''),
(7, 'BE-Electronics and Communication Engineering', 'EC', '', ''),
(8, 'BE-Industrial Engineering and Management', 'IE', '', ''),
(9, 'BE-Information Science and Engineering', 'ISE', '', ''),
(10, 'BE-Instrumentation Technology', 'IT', '', ''),
(11, 'BE-Mechanical Engineering', 'ME', '', ''),
(12, 'BE-Telecommunication Engineering', 'TE', '', ''),
(13, 'EKA Designs Pvt. Ltd.', 'EKA', '', ''),
(14, 'M.Tech Chemical Engineering', 'MCE', '', ''),
(15, 'M.Tech-Computer Integrated Manufacturing', 'MCI', '', ''),
(16, 'M.Tech-Computer Network Engineering', 'MCN', '', ''),
(17, 'M.tech-Computer Science and Engineering', 'MCS', '', ''),
(18, 'M.Tech-Digital Communication Engineering', 'MDC', '', ''),
(19, 'M.Tech-Manufacturing Sc. and Engineering Engineering', 'MMS', '', ''),
(20, 'M.Tech-Power Electronics', 'MPE', '', ''),
(21, 'M.Tech-Signal Processing', 'MSP', '', ''),
(22, 'M.Tech-Structural Engineering', 'MSE', '', ''),
(23, 'M.Tech-Thermal Power Engineering', 'MTP', '', ''),
(24, 'M.Tech-Transportation Engineering and Management', 'MTE', '', ''),
(25, 'M.Tech-Cyber Forensics and Information Security', 'MCI', '', ''),
(26, 'M.Tech-Nano Technology', 'MNT', '', ''),
(27, 'M.Tech-VLSI Design and Embedded Systems', 'MDE', '', ''),
(28, 'Master of Computer Applications', 'MCA', '', ''),
(29, 'Master of Business Administration', 'MBA', '', ''),
(30, 'PGDIP-Bioinformatics and Bigdata Analytics', 'BBA', '', ''),
(31, 'PGDIP-Bioinformatics and Rational Drug Design', 'BRD', '', ''),
(32, 'PGDIPBDA-Big Data Analytics', 'BDA', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `SL_NO` int(50) NOT NULL,
  `User_Name` varchar(25) NOT NULL,
  `Password` varchar(25) NOT NULL,
  `role_id` int(50) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `DOB` varchar(50) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `phno` varchar(20) NOT NULL,
  `branch` varchar(100) NOT NULL,
  `email_id` varchar(50) NOT NULL,
  `created_date` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`SL_NO`, `User_Name`, `Password`, `role_id`, `firstname`, `lastname`, `DOB`, `sex`, `phno`, `branch`, `email_id`, `created_date`) VALUES
(0, 'admin', 'admin', 1, 'HARSHITHA', 'VENKATESH', '07-03-2019', 'FEMALE', '1111111111', 'MCE', 'harshitha@gmail.com', '2019-04-17 12:59:39'),
(0, 'har', 'har', 2, 'HARSHITHA', 'V', '14-03-2019', 'FEMALE', '2222222222', 'MCI', 'harshitha@gmail.com', '2019-04-17 13:06:57'),
(0, 'almas', 'almas', 1, 'ALMAS', 'SYED', '14-03-2019', 'MALE', '3333333333', 'ISE', 'almas@gmail.com', '2019-04-17 13:12:22'),
(0, 'shivu', 'shivu', 2, 'SHIVA ', 'KUMAR', '28-02-2019', 'MALE', '6666666666', 'MCA', 'j@gmail.com', '2019-04-22 16:27:06'),
(0, 'SUSH', 'SUSH', 2, 'SUSHMITHA', 'V', '14-03-2019', 'FEMALE', '7777777777', 'MCN', 'x@gmail.com', '2019-04-22 16:32:53');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `SL_NO` int(11) NOT NULL,
  `role_name` varchar(500) NOT NULL,
  `role_id` varchar(500) NOT NULL,
  `created_date` varchar(500) NOT NULL,
  `updated_by` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`SL_NO`, `role_name`, `role_id`, `created_date`, `updated_by`) VALUES
(1, 'admin', '1', '', ''),
(2, 'faculty', '2', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `student_id` int(11) NOT NULL,
  `student_firstname` varchar(100) NOT NULL,
  `student_lastname` varchar(100) NOT NULL,
  `student_usn` varchar(100) NOT NULL,
  `student_phnumber` varchar(100) NOT NULL,
  `student_branch` varchar(100) NOT NULL,
  `student_semester` varchar(100) NOT NULL,
  `student_section` varchar(100) NOT NULL,
  `created_date` varchar(11) NOT NULL,
  `updated_by` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`student_id`, `student_firstname`, `student_lastname`, `student_usn`, `student_phnumber`, `student_branch`, `student_semester`, `student_section`, `created_date`, `updated_by`) VALUES
(1, 'harshitha', 'v', 'w34dfg', '1312369545', 'MCE', 'Third', 'C', '0', '0'),
(2, 'harshitha', 'v', '1frdgdfgf', '1312369545', 'TE', 'Second', 'A', '0', '0'),
(3, 'harshitha', 'grytrur', '1f', '1111111111', 'EE', 'I', 'B', '2147483647', '0'),
(4, 'harshitha', 'd', '1frdgdfgf', '9873037039', 'CS', 'Sixth', 'B', '2147483647', '0'),
(5, 'harshitha', 'Venkatesh', '1si15mca10', '1234567890', 'MCA', 'Sixth', 'B', '2019-04-12 ', 'admin'),
(6, 'hhhh', 'hhhh', '1f', '9999999999', 'MCI', 'Second', 'A', '2019-04-16 ', 'r'),
(7, 'GH', 'HJ', 'H', '1111111111', 'TE', 'Third', 'B', '2019-04-16 ', 'r'),
(8, 'dfgdfg', 'dfgdfg', '234234zdfs', '2343232323', 'BA', 'IV', 'A', '2019-04-17 ', 'aaaa'),
(9, 'sdfgds', 'dfgd', 'dfdfs3435', '3434534534', 'BA', 'IV', 'A', '2019-04-17 ', 'aaaa'),
(10, 'harshitha', 'Venkatesh', '1si15mca10', '1312369545', 'TE', 'I', 'A', '2019-04-17 ', 'sss'),
(11, 'harshitha', 'd', '1si15mca10', '1312369545', 'IE', 'II', 'C', '2019-04-22 ', 'admin'),
(12, 'HARSHITHA', 'VENKATESH', '1SI15MCA10', '1312369545', 'MCA', 'II', 'B', '2019-04-22 ', 'admin'),
(13, 'SYEED', 'ALMAS', '1SI16MCA45', '1234567891', 'MCA', 'II', 'A', '2019-04-22 ', 'admin'),
(14, 'Kushi', 'S', '1si17mca1', '1312369545', 'MCE', 'III', 'C', '', ''),
(15, 'Deepu', 'N', '1si16mca11', '1312369545', 'TE', 'II', 'A', '', ''),
(16, 'Druthi', 'Rai', '1si16mca18', '1111111111', 'EE', 'I', 'B', '', ''),
(17, 'Sanvi', 'D', '1frdgdfgf', '9873037039', 'CS', 'IV', 'B', '', ''),
(18, 'Anu', 'M', '1si16mca11', '1234567890', 'MCA', 'V', 'A', '', ''),
(19, 'MANVI', 'RAI', '1si16mca16', '1234566789', 'MBA', 'I', 'D', '', ''),
(20, 'Kushi', 'S', '1si17mca1', '1312369545', 'MCE', 'III', 'C', '', ''),
(21, 'Deepu', 'N', '1si16mca11', '1312369545', 'TE', 'II', 'A', '', ''),
(22, 'Druthi', 'Rai', '1si16mca18', '1111111111', 'EE', 'I', 'B', '', ''),
(23, 'Sanvi', 'D', '1frdgdfgf', '9873037039', 'CS', 'IV', 'B', '', ''),
(24, 'Anu', 'M', '1si16mca11', '1234567890', 'MCA', 'V', 'A', '', ''),
(25, 'MANVI', 'RAI', '1si16mca16', '1234566789', 'MBA', 'I', 'D', '', ''),
(26, 'Kushi', 'S', '1si17mca1', '1312369545', 'MCE', 'III', 'C', '', ''),
(27, 'Deepu', 'N', '1si16mca11', '1312369545', 'TE', 'II', 'A', '', ''),
(28, 'Druthi', 'Rai', '1si16mca18', '1111111111', 'EE', 'I', 'B', '', ''),
(29, 'Sanvi', 'D', '1frdgdfgf', '9873037039', 'CS', 'IV', 'B', '', ''),
(30, 'Anu', 'M', '1si16mca11', '1234567890', 'MCA', 'V', 'A', '', ''),
(31, 'MANVI', 'RAI', '1si16mca16', '1234566789', 'MBA', 'I', 'D', '', ''),
(32, 'Kushi', 'S', '1si17mca1', '1312369545', 'MCE', 'III', 'C', '', ''),
(33, 'Deepu', 'N', '1si16mca11', '1312369545', 'TE', 'II', 'A', '', ''),
(34, 'Druthi', 'Rai', '1si16mca18', '1111111111', 'EE', 'I', 'B', '', ''),
(35, 'Sanvi', 'D', '1frdgdfgf', '9873037039', 'CS', 'IV', 'B', '', ''),
(36, 'Anu', 'M', '1si16mca11', '1234567890', 'MCA', 'V', 'A', '', ''),
(37, 'MANVI', 'RAI', '1si16mca16', '1234566789', 'MBA', 'I', 'D', '', ''),
(38, 'Kushi', 'S', '1si17mca1', '1312369545', 'MCE', 'III', 'C', '', ''),
(39, 'Deepu', 'N', '1si16mca11', '1312369545', 'TE', 'II', 'A', '', ''),
(40, 'Druthi', 'Rai', '1si16mca18', '1111111111', 'EE', 'I', 'B', '', ''),
(41, 'Sanvi', 'D', '1frdgdfgf', '9873037039', 'CS', 'IV', 'B', '', ''),
(42, 'Anu', 'M', '1si16mca11', '1234567890', 'MCA', 'V', 'A', '', ''),
(43, 'MANVI', 'RAI', '1si16mca16', '1234566789', 'MBA', 'I', 'D', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `attendance_tracker`
--
ALTER TABLE `attendance_tracker`
  ADD PRIMARY KEY (`aid`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`SL_NO`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `attendance_tracker`
--
ALTER TABLE `attendance_tracker`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `SL_NO` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
