<?php    

$usn=$_POST['usn'];
$subcode=$_POST['subcode'];

//require_once("config.php");
$con=mysqli_connect("localhost","root","","sinfo");
$sql1="select * from login where subcode='$subcode'";

$result1=mysqli_query($con,$sql1);

$usn_array="";

while($row1=mysqli_fetch_array($result1))
{
$usn_array=$usn_array.$row1['USN'];

}

$usnArray1 = explode(',', $usn_array);

//counting no of absent class
$count_absent=0;

for($i=0;$i<sizeof($usnArray1);$i++)
{
if(($usnArray1[$i])==$usn)
{
$count_absent=$count_absent+1;
}

}


//counting no of class held
$class_held=0;
//$sql2="select subcode,count(subcode)as tot_count from login group by subcode";//where subcode='$subcode'";
$sql2="select count(subcode) as tot_count,subcode,USN from login  group by subcode";
$result2=mysqli_query($con,$sql2);
while($row2=mysqli_fetch_array($result2))
{
$class_held=$row2['tot_count'];
}

//echo $count_absent." -".$class_held;
$count_present=$class_held-$count_absent;
//echo 

$a=($count_present/$class_held)*100;
$test=$class_held.",".$count_present.",".$a;
echo $test;
//echo $count_present;

//echo ($usnArray1[1]);




?>

