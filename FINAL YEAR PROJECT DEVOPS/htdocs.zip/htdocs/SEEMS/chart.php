<?php
include('config.php');


$data[] = array('Branch','count');


$pb[]=array();

$sql1 = "SELECT count(`branch`) as count, `branch` FROM `user_mst` group by `branch` order by count desc limit 5";
$query1 = mysqli_query($conn,$sql1);


while($result = mysqli_fetch_array($query1))
{

  
  $rows[]=array("c"=>array("0"=>array("v"=>$result['branch'],"f"=>NULL),"1"=>array("v"=>(int)$result['count'],"f" 
=>NULL)));

}

echo $format = '{
"cols":
[
{"id":"","label":"Branch","pattern":"","type":"string"},
{"id":"","label":"count","pattern":"","type":"number"}
],
"rows":'.json_encode($rows).'}';

  



?>