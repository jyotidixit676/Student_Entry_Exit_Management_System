<?php
date_default_timezone_set('Asia/Kolkata');
    echo $timestamp = date('d/m/Y H:i:s');
	?>